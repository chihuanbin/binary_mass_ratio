# PASP CMD mass-ratio benchmark — R7 story and science revision

This is a derived-artifact review supplement for a specific, support-conditioned
CMD-to-\((M_1,q)\) pipeline. It is not a public data release, a submission, or
a full raw-to-response reproduction. The paper's central question is what
evidence supports a claim about photometric binary mass-ratio structure. Test
sensitivity, reconstruction error relative to an explicit baseline, and
marginal interval coverage are reported as separate checks.

## Reproduction levels and actual evidence

Recorded environment: Python 3.13.5, NumPy 2.1.3, SciPy 1.15.3, Matplotlib
3.10.0 using `/opt/anaconda3/bin/python`; manuscript built with the local TeX
Live 2026 AASTeX 7.0.1 toolchain. Project-root-relative commands are listed in
[`docs/USING_BENCHMARK.md`](docs/USING_BENCHMARK.md).

### Derived-artifact reproduction — previously accepted; R7 plot updated

Previously accepted commands (R6 logs retained in `reports/`) regenerate the
truth vectors, reconstruction summary, response/power/proposal figures, and
their source data. In R7, the reconstruction plot was regenerated to show the
analytic fixed-uniform reference at 0 for S0 (coincident with the y-axis) and
0.0044998269 for S1. The new deterministic response-projection figure was
generated and smoke-checked from the packaged matrix and truth vectors. These
operations do not rerun the underlying outer inference fits or internal
bootstrap samples.

The main focused null result is retained from its verified execution:
482/10,000 Pearson and 563/10,000 LR rejections. It is conditional on the
frozen matrix and thresholds and checks one focus only. No full-grid null-size
validation is claimed. The current LR power surface shows 56 single-q-bin LR
cells. The full historical 672-cell grid is not claimed to be bitwise
reproduced; three known two-q-bin integer-count mismatches remain recorded and
outside that plotted surface. Do not describe this as `669/672` passed.

The reconstruction archive includes 20 outer realizations per truth at
N=20,000 and archived interval summaries. Each realization's 1,000 internal
bootstrap draws are not 1,000 external validation populations. The saved
outputs do not include per-state error vectors or interval endpoints; the
paper therefore reports only supported aggregate/local summaries and does not
claim those missing quantities were recomputed.

### Frozen-operator conditional experiment — not a portable package command

No full package-root runner is claimed. The legacy
`src/legacy_scripts/exp5_operator_uncertainty.py` imports successfully but
expects `src/results/calibration_200k.npz` and writes into `src/results/`.
The packaged calibration file is instead
`data/derived/legacy_results/calibration_200k.npz`. The older targeted replay
of 40 outer estimates and 4,000 sampled internal fits is limited diagnostic
evidence only: sampled fits reached the 200-iteration cap without the
monitored numerical guard. It does not show convergence or characterize
unexamined fits.

### Raw inputs to response — NOT RUN

Raw MIST isochrones and full cluster/member catalogues were not reprocessed in
this revision. The frozen matrix is conditional on the documented within-bin
draws, support rule, nuisance sampling, magnitude-noise model, sensitivity
cuts, and inverse grid. Proposal replay counts have summary agreement but
were not recertified event by event; proposal events are not linked to the
calibration quota. The arithmetic difference 45,598 is not assigned to a
quota-surplus or observation-loss category.

## R7 changes and scope

- Reframed the Introduction around evidence matching the scientific claim and
  fairly located the work relative to validated CMD mixture methods.
- Connected component-flux addition, apparent photometry, finite-grid
  inversion, and the response operator in the Methods.
- Reorganized Results around test-dependent sensitivity, reconstruction
  against a fixed-uniform output, and marginal coverage.
- Added a labeled deterministic projection diagnostic for two separate,
  already-defined contrasts. No scientific Monte Carlo was run in R7.
- Added a use guide, a claim/evidence/scope map, and a concise change log.
- Did not change scientific truths, seeds, response, thresholds, iteration
  budgets, or author metadata. Author names/order, affiliations, contacts,
  funding, ORCID, and anonymity remain `AWAITING_AUTHOR` in
  `submission/AUTHOR_METADATA_QUERY.txt`.

The response is not transferable as-is to a new cluster. Real-catalogue
selection/completeness, spatially varying membership selection, external
controls, crowding, triples, and model mismatch remain untested. Inverse fits
condition on the true age, distance, extinction, and metallicity. The package
has not been publicly released, submitted, or assigned a DOI.
