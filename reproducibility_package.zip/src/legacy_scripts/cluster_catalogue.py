"""Cluster master catalogue from Hunt & Reffert (2024) + Netopil (2016).

The catalogue is the 6 well-studied clusters used in the paper (params.csv),
each with (log_age, AV, MOD, dist_pc) from Hunt+2024 and [Fe/H] from
Netopil+2016 (HQS-preferred).  Cluster selection during population sampling
is weighted by the number of high-quality members in the Hunt+2024
membership table.

Sampling model (per simulated system):
  * draw a cluster c ~ member-count weights
  * log_age  ~ N(log_age_c, 0.15)
  * feh      ~ N(feh_c, 0.08)  (physical scatter, clipped to MIST grid)
  * dist     ~ N(dist_c, 0.15 * dist_c) with lower bound 0
  * AV       ~ N(AV_c, 0.05) clipped to >= 0
This reproduces the "joint sampling from the cluster master catalogue" of the
manuscript at a level appropriate for the calibration study.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

DATA = Path(__file__).resolve().parents[1] / "data"


class ClusterCatalogue:
    def __init__(self, params_csv: str | Path | None = None,
                 members_dat: str | Path | None = None) -> None:
        params_csv = Path(params_csv or DATA / "hunt24" / "params.csv")
        self.params = pd.read_csv(params_csv)
        if "feh" not in self.params.columns:
            raise ValueError("params.csv must contain a 'feh' column "
                             "(add Netopil+2016 metallicities)")
        # member counts for weighting
        self.member_counts = self._count_members(members_dat)
        self.params["n_members"] = self.params["hunt_name"].map(
            lambda n: self.member_counts.get(n, 0))
        self._weights = np.maximum(self.params["n_members"].to_numpy(float), 1.0)
        self._weights /= self._weights.sum()

    @staticmethod
    def _count_members(members_dat: str | Path | None) -> dict[str, int]:
        counts: dict[str, int] = {}
        if members_dat is None:
            return counts
        path = Path(members_dat)
        if not path.exists():
            return counts
        with open(path) as f:
            for line in f:
                if len(line) < 30:
                    continue
                name = line[8:28].strip()
                counts[name] = counts.get(name, 0) + 1
        return counts

    def clusters(self) -> pd.DataFrame:
        return self.params

    def draw(self, n: int, rng: np.random.Generator,
             subset: np.ndarray | None = None) -> pd.DataFrame:
        """Draw n systems: columns cluster, log_age, feh, dist_pc, AV, MOD.

        ``subset``: boolean mask over self.params to draw from (used for
        M1-conditioned sampling).  Weights are renormalized over the subset.
        """
        if subset is None:
            w = self._weights
            idx = rng.choice(len(self.params), size=n, p=w)
        else:
            sub = np.asarray(subset, dtype=bool)
            if not sub.any():
                raise ValueError("empty subset in draw")
            w = self._weights * sub
            w = w / w.sum()
            idx = rng.choice(len(self.params), size=n, p=w)
        rows = self.params.iloc[idx]
        log_age = rows["log_age"].to_numpy(float) + rng.normal(0.0, 0.15, n)
        feh = rows["feh"].to_numpy(float) + rng.normal(0.0, 0.08, n)
        dist = np.maximum(
            rows["dist_pc"].to_numpy(float) * (1.0 + rng.normal(0.0, 0.15, n)), 10.0)
        av = np.maximum(rows["AV"].to_numpy(float) + rng.normal(0.0, 0.05, n), 0.0)
        mod = rows["MOD"].to_numpy(float)
        return pd.DataFrame({
            "cluster": rows["cluster"].to_numpy(),
            "log_age": log_age,
            "feh": feh,
            "dist_pc": dist,
            "AV": av,
            "MOD": mod,
            "n_members": rows["n_members"].to_numpy(),
        })

    def draw_m1_conditioned(self, m1_lo: float, m1_hi: float, n: int,
                            rng: np.random.Generator,
                            ms_support_fn) -> pd.DataFrame:
        """Draw n systems whose drawn isochrone supports primaries in
        [m1_lo, m1_hi].  ``ms_support_fn(feh, log_age) -> (lo, hi)|None``
        is the phase-0 MS mass support of the isochrone.  We sample cluster
        candidates and reject draws whose support does not cover [m1_lo,
        m1_hi]; this removes the age-M1 physically impossible combinations
        at draw time (they are still counted separately by the caller via
        the returned ``n_rejected`` metadata if needed).

        Returns (df, n_attempts).
        """
        attempts = 0
        out: list[pd.DataFrame] = []
        while sum(len(d) for d in out) < n:
            batch = max(int((n - sum(len(d) for d in out)) * 1.6), 8)
            d = self.draw(batch, rng)
            attempts += batch
            lo = np.full(batch, np.nan)
            hi = np.full(batch, np.nan)
            for i in range(batch):
                s = ms_support_fn(d["feh"].iloc[i], d["log_age"].iloc[i])
                if s is not None:
                    lo[i], hi[i] = s
            keep = (lo <= m1_lo) & (hi >= m1_hi)
            out.append(d[keep])
        df = pd.concat(out, ignore_index=True).iloc[:n].reset_index(drop=True)
        return df, attempts
