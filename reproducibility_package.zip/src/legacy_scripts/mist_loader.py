"""MIST v1.2 UBVRIplus isochrone loader and main-sequence interpolator.

The data product is the photometric isochrone grid
``MIST_v1.2_vvcrit0.4_UBVRIplus/*.iso.cmd`` (16 [Fe/H] values, 107 ages,
5 <= logAge <= 10.3).  Each file block is one isochrone with 270 EEP rows and
34 columns; columns 31--33 are the Gaia EDR3 G/BP/RP absolute magnitudes and
column 34 is the evolutionary phase.  Phase 0 is the main sequence.

This module provides:
  * ``load_grid(data_dir)`` -> dict[(feh, log_age)] -> array (mass, G, BP, RP)
  * ``MSInterpolator``: per (feh, log_age) monotone mass -> (G, BP, RP) spline
    restricted to phase-0 (main-sequence) rows.

NOTE: the published manuscript text referred to "MIST v2.5"; the auditable
grid available for this rerun is MIST v1.2.  The rerun therefore reports
results for MIST v1.2 and the manuscript is updated accordingly.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

import numpy as np
from scipy.interpolate import PchipInterpolator

# column indices in the .iso.cmd photometric files (0-based)
COL_AGE = 1
COL_MINIT = 2
COL_SMASS = 3
COL_LOGT = 4
COL_LOGG = 5
COL_G = 30
COL_BP = 31
COL_RP = 32
COL_PHASE = 33

DATA_COLS = (COL_AGE, COL_MINIT, COL_SMASS, COL_LOGT, COL_LOGG,
             COL_G, COL_BP, COL_RP, COL_PHASE)

PHASE_MS = 0  # MIST phase 0 = main sequence
PHASE_PMS = -1  # MIST phase -1 = pre-main sequence (contracting toward ZAMS)
# The interpolation domain is the union of the phase-0 (MS) and phase--1
# (PMS) rows.  In a young cluster the lowest-mass stars are still on the
# PMS; their photometry is continuous with the MS at the boundary, so a
# binary secondary with q*M1 below the phase-0 floor is still observable
# and must not be classified as physically impossible.
USE_PHASES = (PHASE_MS, PHASE_PMS)


def _feh_from_name(name: str) -> float:
    """Extract [Fe/H] from e.g. MIST_v1.2_feh_m0.25_afe_p0.0_..."""
    m = re.search(r"_feh_([mp]\d+\.\d+)_", name)
    if m is None:
        raise ValueError(f"cannot parse feh from {name}")
    tag = m.group(1)
    sign = -1.0 if tag.startswith("m") else 1.0
    return sign * float(tag[1:])


def load_isochrone_blocks(path: Path) -> dict[float, np.ndarray]:
    """Parse a .iso.cmd file into {log_age: (270, 9) array}."""
    blocks: dict[float, np.ndarray] = {}
    lines = open(path).readlines()
    i = 0
    n = len(lines)
    while i < n:
        if lines[i].lstrip().startswith("# EEP"):
            j = i + 1
            rows = []
            while j < n and not lines[j].startswith("#"):
                rows.append(lines[j])
                j += 1
            if rows:
                arr = np.loadtxt(rows, usecols=DATA_COLS)
                ages = np.unique(arr[:, 0])
                for age in ages:
                    sel = arr[np.abs(arr[:, 0] - age) < 1e-9]
                    blocks[float(age)] = sel
            i = j
        else:
            i += 1
    return blocks


def load_grid(data_dir: str | os.PathLike) -> dict[tuple[float, float], np.ndarray]:
    """Load the full grid: {(feh, log_age): array (n, 9)}.

    Columns: log_age, minit, smass, logTeff, logg, G0, BP0, RP0, phase.
    """
    data_dir = Path(data_dir)
    grid: dict[tuple[float, float], np.ndarray] = {}
    for path in sorted(data_dir.glob("MIST_v1.2_feh_*_afe_p0.0_vvcrit0.4_UBVRIplus.iso.cmd")):
        feh = _feh_from_name(path.name)
        for age, arr in load_isochrone_blocks(path).items():
            grid[(feh, age)] = arr
    return grid


def available_ages(grid: dict[tuple[float, float], np.ndarray]) -> np.ndarray:
    return np.array(sorted({k[1] for k in grid}))


def available_feh(grid: dict[tuple[float, float], np.ndarray]) -> np.ndarray:
    return np.array(sorted({k[0] for k in grid}))


class MSInterpolator:
    """Monotone mass -> (G, BP, RP) interpolator for the phase-0 main sequence.

    For each (feh, log_age) we keep the phase-0 rows sorted by mass and build
    a PCHIP spline for each band.  Requests outside the covered mass interval
    return NaN so the caller can classify them as outside the model domain.
    """

    def __init__(self, grid: dict[tuple[float, float], np.ndarray],
                 feh_values: np.ndarray | None = None,
                 ages: np.ndarray | None = None) -> None:
        self.grid = grid
        self.feh_values = (available_feh(grid) if feh_values is None
                           else np.asarray(feh_values))
        self.ages = (available_ages(grid) if ages is None else np.asarray(ages))
        self._cache: dict[tuple[float, float], tuple[np.ndarray, list[PchipInterpolator]]] = {}

    def _get(self, feh: float, log_age: float):
        feh_s = self.feh_nearest(feh)
        age_s = self.age_nearest(log_age)
        key = (feh_s, age_s)
        if key in self._cache:
            return self._cache[key]
        arr = self.grid.get(key)
        if arr is None:
            self._cache[key] = (None, None)
            return None, None
        ms = arr[np.isin(arr[:, 8], USE_PHASES)]
        ms = ms[np.isfinite(ms[:, 5]) & np.isfinite(ms[:, 6]) & np.isfinite(ms[:, 7])]
        if len(ms) < 4:
            self._cache[key] = (None, None)
            return None, None
        order = np.argsort(ms[:, 2])
        ms = ms[order]
        mass = ms[:, 2]
        splines = [PchipInterpolator(mass, ms[:, 5 + k]) for k in range(3)]
        self._cache[key] = (mass, splines)
        return mass, splines

    def mags(self, feh, log_age, mass: np.ndarray) -> np.ndarray:
        """Return (n, 3) array of (G, BP, RP); NaN outside the domain.

        feh / log_age may be scalars or arrays of length n.  Vectorized:
        systems are grouped by their snapped (feh, age) grid key and each
        group is evaluated with a single PCHIP call per band.
        """
        mass = np.atleast_1d(np.asarray(mass, dtype=float))
        n = len(mass)
        out = np.full((n, 3), np.nan)
        feh_a = np.broadcast_to(np.atleast_1d(np.asarray(feh, dtype=float)), (n,))
        age_a = np.broadcast_to(np.atleast_1d(np.asarray(log_age, dtype=float)), (n,))

        # snap all keys at once
        feh_idx = np.array([np.argmin(np.abs(self.feh_values - f)) for f in feh_a])
        age_idx = np.array([np.argmin(np.abs(self.ages - a)) for a in age_a])
        keys = sorted(set(zip(feh_idx.tolist(), age_idx.tolist())))
        for fi, ai in keys:
            kf, ka = float(self.feh_values[fi]), float(self.ages[ai])
            sel = np.where((feh_idx == fi) & (age_idx == ai))[0]
            mass_ax, splines = self._get(kf, ka)
            if mass_ax is None:
                continue
            lo, hi = mass_ax[0], mass_ax[-1]
            msel = mass[sel]
            ok = (msel >= lo) & (msel <= hi)
            if not ok.any():
                continue
            idx = sel[ok]
            for k in range(3):
                out[idx, k] = splines[k](msel[ok])
        return out

    def mass_support(self, feh: float, log_age: float) -> tuple[float, float] | None:
        mass_ax, _ = self._get(feh, log_age)
        if mass_ax is None:
            return None
        return float(mass_ax[0]), float(mass_ax[-1])

    def feh_nearest(self, feh) -> float:
        feh = np.atleast_1d(np.asarray(feh, dtype=float))
        return float(self.feh_values[np.argmin(np.abs(self.feh_values - feh))])

    def age_nearest(self, log_age) -> float:
        log_age = np.atleast_1d(np.asarray(log_age, dtype=float))
        return float(self.ages[np.argmin(np.abs(self.ages - log_age))])

    def feh_bracket(self, feh) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """(lo, hi, weight) for linear interpolation in [Fe/H]; array-safe."""
        vals = self.feh_values
        feh = np.atleast_1d(np.asarray(feh, dtype=float))
        t = np.clip(feh, vals[0], vals[-1])
        hi = np.searchsorted(vals, t, side="right")
        hi = np.minimum(np.maximum(hi, 1), len(vals) - 1)
        lo = hi - 1
        w = np.zeros_like(t)
        nz = vals[hi] != vals[lo]
        w[nz] = (t[nz] - vals[lo[nz]]) / (vals[hi[nz]] - vals[lo[nz]])
        return vals[lo], vals[hi], w

    def mags_bilinear(self, feh, log_age, mass: np.ndarray) -> np.ndarray:
        """Bilinear in ([Fe/H], logAge); returns (n, 3) or NaN. Array-safe."""
        feh = np.atleast_1d(np.asarray(feh, dtype=float))
        log_age = np.atleast_1d(np.asarray(log_age, dtype=float))
        mass = np.atleast_1d(np.asarray(mass, dtype=float))
        n = len(mass)
        fl, fh, wf = self.feh_bracket(feh)          # (n,)
        ages = self.ages
        la = np.clip(log_age, ages[0], ages[-1])
        ai = np.searchsorted(ages, la, side="right") - 1
        ai = np.minimum(np.maximum(ai, 0), len(ages) - 2)
        wa = (la - ages[ai]) / (ages[ai + 1] - ages[ai])
        m_ll = self.mags(fl, ages[ai], mass)
        m_lh = self.mags(fl, ages[ai + 1], mass)
        m_hl = self.mags(fh, ages[ai], mass)
        m_hh = self.mags(fh, ages[ai + 1], mass)
        m0 = (1 - wf)[:, None] * ((1 - wa)[:, None] * m_ll + wa[:, None] * m_lh)
        m0 += wf[:, None] * ((1 - wa)[:, None] * m_hl + wa[:, None] * m_hh)
        return m0
