"""Forward simulation and inverse CMD fit for the binary mass-ratio operator.

Vectorized batch simulation (no per-system Python loop in the hot path).

Forward (per system):
  1. draw cluster + (log_age, feh, dist, AV) from the catalogue
  2. draw primary mass M1 in one of the six bins, mass ratio q uniform
  3. absolute MS magnitudes (G, BP, RP) of M1 and q*M1 from the MIST
     phase-0 interpolator (bilinear in feh and log_age)
  4. binary flux addition -> apparent magnitudes with distance modulus and
     extinction (A_G = 0.789 A_V, A_BP = 1.083 A_V, A_RP = 0.634 A_V)
  5. photometric noise from the calibrated magnitude-dependent relations
  6. sensitivity selection: finite 3-band photometry, G < 20, max band
     uncertainty < 0.1 mag

Loss decomposition (NOT_OBSERVED):
  * AGE_M1_INCOMPATIBLE : primary/secondary outside the MS mass support of
    the drawn isochrone (physically impossible combination, not Gaia loss)
  * MIST_DOMAIN         : inside mass support but interpolation returned NaN
  * INVERSE_FAILURE     : finite photometry but inverse grid fit failed
  * G_CUT / SIGMA_CUT   : Gaia sensitivity selection rejects the system

Inverse fit: chi2(M1, q) over the grid; returns the best grid state.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from mist_loader import MSInterpolator
from cluster_catalogue import ClusterCatalogue

# M1 bin edges (Msun) -- six intervals from the manuscript
M1_EDGES = np.array([1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0])
N_M1 = len(M1_EDGES) - 1
Q_EDGES = np.linspace(0.1, 1.0, 10)          # 9 q bins of width 0.1
N_Q = len(Q_EDGES) - 1
N_TRUE = N_M1 * N_Q                          # 54 true states

# extinction coefficients (manuscript)
A_G_FAC, A_BP_FAC, A_RP_FAC = 0.789, 1.083, 0.634

# sensitivity cuts
G_LIMIT = 20.0
SIGMA_LIMIT = 0.1

# loss reason codes
(L_AGE_M1, L_DOMAIN, L_INVF, L_GCUT, L_SIGMA, L_FINITE) = range(6)
LOSS_NAMES = ["age_M1_incompatible", "MIST_domain", "inverse_failure",
              "G_cut", "sigma_cut", "nonfinite_phot"]


def m1_bin_index(mass: np.ndarray) -> np.ndarray:
    return np.clip(np.searchsorted(M1_EDGES, mass, side="right") - 1, 0, N_M1 - 1)


def q_bin_index(q: np.ndarray) -> np.ndarray:
    return np.clip(np.searchsorted(Q_EDGES, q, side="right") - 1, 0, N_Q - 1)


def true_state_index(m1_bin: np.ndarray, q_bin: np.ndarray) -> np.ndarray:
    return m1_bin * N_Q + q_bin


class ForwardModel:
    def __init__(self, grid, catalogue: ClusterCatalogue, err_model,
                 q_step: float = 0.02, m1_grid: np.ndarray | None = None) -> None:
        self.ms = MSInterpolator(grid)
        self.catalogue = catalogue
        self.err_model = err_model
        self.q_step = q_step
        self.q_grid = np.arange(0.1, 1.0 + 1e-9, q_step)
        if m1_grid is None:
            # 105 points over 1-5 Msun as in the manuscript
            self.m1_grid = np.linspace(1.0, 5.0, 105)
        else:
            self.m1_grid = np.asarray(m1_grid)
        self._grid_mags_cache: dict[tuple, np.ndarray] = {}

    # ------------------------------------------------------------------
    def _grid_mags(self, feh: float, log_age: float):
        """Model binary magnitudes on the (m1_grid x q_grid) for a fixed
        (feh, log_age): shape (3, n_m1, n_q)."""
        key = (self.ms.feh_nearest(feh), self.ms.age_nearest(log_age))
        if key in self._grid_mags_cache:
            return self._grid_mags_cache[key]
        m1 = self.m1_grid
        q = self.q_grid
        mag1 = self.ms.mags(key[0], key[1], m1)                 # (n_m1, 3)
        m2 = q[:, None] * m1[None, :]                           # (n_q, n_m1)
        mag2 = self.ms.mags(key[0], key[1], m2.ravel()).reshape(len(q), len(m1), 3)
        f1 = 10.0 ** (-0.4 * mag1)                              # (n_m1, 3)
        f2 = 10.0 ** (-0.4 * mag2)                              # (n_q, n_m1, 3)
        fsum = f1[None, :, :] + f2
        mcomb = -2.5 * np.log10(fsum)                           # (n_q, n_m1, 3)
        out = np.moveaxis(mcomb, 2, 0)                          # (3, n_q, n_m1)
        self._grid_mags_cache[key] = out
        return out

    # ------------------------------------------------------------------
    def inverse_fit(self, m_obs: np.ndarray, sigma: np.ndarray,
                    feh: float, log_age: float):
        """Grid chi2 minimization; returns (m1_rec, q_rec) or None."""
        mmod = self._grid_mags(feh, log_age)          # (3, n_q, n_m1)
        obs = m_obs[:, None, None]
        sig = sigma[:, None, None]
        chi2 = np.sum(((obs - mmod) / sig) ** 2, axis=0)   # (n_q, n_m1)
        if not np.all(np.isfinite(chi2)):
            finite = np.isfinite(chi2)
            if not finite.any():
                return None
            chi2 = np.where(finite, chi2, np.inf)
        iq, im1 = np.unravel_index(int(np.argmin(chi2)), chi2.shape)
        return float(self.m1_grid[im1]), float(self.q_grid[iq])

    # ------------------------------------------------------------------
    def simulate_population_vectorized(self, m1_true: np.ndarray,
                                       q_true: np.ndarray, params: dict,
                                       seed: int):
        """Vectorized batch simulation of a population.

        Returns dict with:
          loss     (n,) int codes (or -1 observed)
          obs_m1, obs_q  (n,) recovered state (NaN if not observed)
          m_obs    (n,3) observed magnitudes (NaN if not observed)
          sigma    (n,3)
        """
        rng = np.random.Generator(np.random.PCG64(seed))
        n = len(m1_true)
        loss = np.full(n, -1, dtype=int)

        log_age = np.asarray(params["log_age"], dtype=float)
        feh = np.asarray(params["feh"], dtype=float)
        dist = np.asarray(params["dist_pc"], dtype=float)
        av = np.asarray(params["AV"], dtype=float)
        dm = 5.0 * np.log10(np.maximum(dist, 1e-3)) - 5.0

        m2_true = q_true * m1_true

        # absolute magnitudes of both components (bilinear)
        mabs1 = self.ms.mags_bilinear(feh, log_age, m1_true)    # (n,3)
        mabs2 = self.ms.mags_bilinear(feh, log_age, m2_true)    # (n,3)
        bad = ~(np.all(np.isfinite(mabs1), axis=1) & np.all(np.isfinite(mabs2), axis=1))
        loss[bad] = L_AGE_M1

        # flux addition
        f1 = 10.0 ** (-0.4 * mabs1)
        f2 = 10.0 ** (-0.4 * mabs2)
        with np.errstate(invalid="ignore", divide="ignore"):
            mcomb = -2.5 * np.log10(f1 + f2)
        a_g, a_bp, a_rp = A_G_FAC * av, A_BP_FAC * av, A_RP_FAC * av
        m_app = mcomb + dm[:, None] + np.column_stack([a_g, a_bp, a_rp])
        nonfin = ~np.all(np.isfinite(m_app), axis=1)
        loss[nonfin & (loss < 0)] = L_DOMAIN

        # photometric noise (only for systems not already lost)
        m_obs = np.full((n, 3), np.nan)
        sigma = np.full((n, 3), np.nan)
        alive = loss < 0
        if alive.any():
            m_app_a = m_app[alive]
            sig_a = self.err_model(m_app_a)
            sigma[alive] = sig_a
            m_obs[alive] = m_app_a + rng.normal(0.0, sig_a)

        # sensitivity selection
        gcut = alive & (m_obs[:, 0] > G_LIMIT)
        loss[gcut] = L_GCUT
        scut = alive & ~gcut & (sigma.max(axis=1) > SIGMA_LIMIT)
        loss[scut] = L_SIGMA
        nfin = alive & ~gcut & ~scut & ~np.all(np.isfinite(m_obs), axis=1)
        loss[nfin] = L_FINITE

        # inverse fit for surviving systems
        obs_m1 = np.full(n, np.nan)
        obs_q = np.full(n, np.nan)
        surv = loss < 0
        if surv.any():
            # apparent-model magnitudes = abs + distance modulus + extinction
            dm_s = 5.0 * np.log10(np.maximum(dist[surv], 1e-3)) - 5.0
            a_s = np.column_stack([A_G_FAC * av[surv], A_BP_FAC * av[surv],
                                   A_RP_FAC * av[surv]])
            # group surviving systems by (feh_snap, age_snap) grid key
            feh_s = np.array([self.ms.feh_nearest(f) for f in feh[surv]])
            age_s = np.array([self.ms.age_nearest(a) for a in log_age[surv]])
            keys = list(dict.fromkeys(zip(feh_s, age_s)))
            for kf, ka in keys:
                sel = np.where((feh_s == kf) & (age_s == ka))[0]
                idx = np.where(surv)[0][sel]
                mmod = self._grid_mags(kf, ka)                    # (3, nq, nm1)
                # observed - apparent model: add dm and extinction per system
                app = mmod[None] + (dm_s[sel, None, None, None] +
                                    a_s[sel, :, None, None])
                chi2 = np.sum(((m_obs[idx, :, None, None] - app) /
                               sigma[idx, :, None, None]) ** 2, axis=1)  # (nsel, nq, nm1)
                finite = np.isfinite(chi2)
                chi2 = np.where(finite, chi2, np.inf)
                ok = finite.any(axis=(1, 2))
                for j in np.where(ok)[0]:
                    iq, im1 = np.unravel_index(int(np.argmin(chi2[j])), chi2[j].shape)
                    obs_m1[idx[j]] = self.m1_grid[im1]
                    obs_q[idx[j]] = self.q_grid[iq]
                if (~ok).any():
                    loss[idx[~ok]] = L_INVF

        return {"loss": loss, "obs_m1": obs_m1, "obs_q": obs_q,
                "m_obs": m_obs, "sigma": sigma}
