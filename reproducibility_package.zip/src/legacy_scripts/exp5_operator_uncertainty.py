"""Experiment 5 (plan_v2 confirmatory gate): coverage and operator uncertainty.

For each of 20 independent validation data sets, construct marginal 68 per cent
percentile intervals for all 54 latent-state fractions using:

  1. fixed-R parametric bootstrap (n* only), and
  2. joint bootstrap (independent Dirichlet R* plus n*).

Coverage is the fraction of the 20 x 54 intervals containing the known input
fraction.  We report a Wilson interval over the pooled indicators, plus a
cluster bootstrap over validation seeds because bins within a seed are not
independent.  This replaces the earlier percentile-rank diagnostic that was
incorrectly labelled as interval coverage.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from unfolding import dagostini_observable_only
from forward_model import N_M1, N_Q, N_TRUE, M1_EDGES, Q_EDGES

OUT = Path(__file__).resolve().parents[1] / "results"


def wilson_interval(successes: int, trials: int, z: float = 1.959963984540054) -> tuple[float, float]:
    """Two-sided Wilson score interval for a binomial proportion."""
    phat = successes / trials
    denom = 1.0 + z * z / trials
    center = (phat + z * z / (2.0 * trials)) / denom
    half = z * np.sqrt(phat * (1.0 - phat) / trials + z * z / (4.0 * trials**2)) / denom
    return float(center - half), float(center + half)


def clustered_mean_interval(values: np.ndarray, rng: np.random.Generator,
                            n_boot: int = 20_000) -> tuple[float, float]:
    """Percentile interval after resampling independent validation seeds."""
    draw = rng.choice(values, size=(n_boot, len(values)), replace=True).mean(axis=1)
    lo, hi = np.quantile(draw, [0.025, 0.975])
    return float(lo), float(hi)


def q_centers():
    return 0.5 * (Q_EDGES[:-1] + Q_EDGES[1:])


def mean_q_from_states(t: np.ndarray) -> float:
    t = t.reshape(N_M1, N_Q)
    w = t.sum(axis=1)
    mq = (t * q_centers()[None, :]).sum(axis=1) / np.maximum(w, 1e-12)
    return float((mq * w).sum() / max(w.sum(), 1e-12))


def main() -> None:
    cal = np.load(OUT / "calibration_200k.npz", allow_pickle=True)
    R = cal["R"]
    n_per_state = cal["n_per_state"]
    counts = R * n_per_state[:, None]

    t0_s0 = np.full(N_TRUE, 1.0 / N_TRUE)
    t0_s1 = np.full(N_TRUE, 1.0 / N_TRUE).reshape(N_M1, N_Q)
    t0_s1[3, 3] *= 0.75
    t0_s1[3, 4] *= 0.75
    t0_s1 = t0_s1.ravel() / t0_s1.sum()

    n_seed = 20
    n_sys = 20_000
    B = 1000
    N_OP = 200
    rng = np.random.Generator(np.random.PCG64(999))

    def project(R_use, t):
        Rd = R_use[:, :-1]
        eps = Rd.sum(axis=1); eps[eps <= 0] = 1e-12
        p = (Rd.T @ t) / (eps @ t)
        p = np.clip(p, 1e-12, None)
        return p / p.sum()

    def draw_operator():
        Rstar = np.zeros_like(R)
        for i in range(R.shape[0]):
            row = counts[i]
            Rstar[i] = rng.dirichlet(row + 1.0) if row.sum() > 0 else R[i]
        return Rstar

    def coverage_summary(indicators: np.ndarray, widths: np.ndarray) -> dict:
        successes = int(indicators.sum())
        trials = int(indicators.size)
        per_seed = indicators.mean(axis=1)
        simultaneous = np.all(indicators, axis=1)
        simultaneous_successes = int(simultaneous.sum())
        return {
            "definition": "marginal 16th-84th percentile interval coverage across latent bins",
            "successes": successes,
            "trials": trials,
            "mean": float(successes / trials),
            "wilson_95": list(wilson_interval(successes, trials)),
            "cluster_seed_bootstrap_95": list(clustered_mean_interval(per_seed, rng)),
            "per_seed": per_seed.tolist(),
            "simultaneous_all_bins": {
                "successes": simultaneous_successes,
                "trials": int(len(simultaneous)),
                "mean": float(simultaneous.mean()),
                "wilson_95": list(wilson_interval(simultaneous_successes, len(simultaneous))),
            },
            "mean_interval_width": float(widths.mean()),
        }

    results = {}
    for name, t0 in [("S0", t0_s0), ("S1", t0_s1)]:
        pA = project(R, t0)
        maxbias, meanq = [], []
        fixed_indicators, joint_indicators = [], []
        fixed_widths, joint_widths = [], []
        for s in range(n_seed):
            n_det = rng.multinomial(n_sys, pA)
            pi = dagostini_observable_only(R, n_det, n_iter=200)
            mb = float(np.abs(pi - t0).max())
            maxbias.append(mb)
            meanq.append(mean_q_from_states(pi))
            # Parametric bootstrap around the fitted latent population.  The
            # validation truth t0 is used only for the outer coverage check.
            p_fit = project(R, pi)
            boot_fixed = np.empty((B, N_TRUE))
            boot_joint = np.empty((B, N_TRUE))
            for b in range(B):
                nb = rng.multinomial(n_sys, p_fit)
                boot_fixed[b] = dagostini_observable_only(R, nb, n_iter=200)

                # Calibration and validation samples are independent.  Draw
                # R* for the inverse while resampling n* from the nominal
                # fitted detected distribution.
                Rstar = draw_operator()
                nb_joint = rng.multinomial(n_sys, p_fit)
                boot_joint[b] = dagostini_observable_only(Rstar, nb_joint, n_iter=200)

            lo_f, hi_f = np.quantile(boot_fixed, [0.16, 0.84], axis=0)
            lo_j, hi_j = np.quantile(boot_joint, [0.16, 0.84], axis=0)
            fixed_indicators.append((lo_f <= t0) & (t0 <= hi_f))
            joint_indicators.append((lo_j <= t0) & (t0 <= hi_j))
            fixed_widths.append(hi_f - lo_f)
            joint_widths.append(hi_j - lo_j)
            print(f"{name} seed {s + 1:02d}/{n_seed}: maxbias={mb:.4f}", flush=True)
        maxbias = np.array(maxbias)
        fixed_indicators = np.asarray(fixed_indicators, dtype=bool)
        joint_indicators = np.asarray(joint_indicators, dtype=bool)
        fixed_widths = np.asarray(fixed_widths)
        joint_widths = np.asarray(joint_widths)
        results[name] = {
            "max_bin_bias": {"mean": float(maxbias.mean()),
                             "median": float(np.median(maxbias)),
                             "p90": float(np.quantile(maxbias, 0.90)),
                             "p95": float(np.quantile(maxbias, 0.95)),
                             "all": maxbias.tolist()},
            "coverage_fixed_R": coverage_summary(fixed_indicators, fixed_widths),
            "coverage_joint_R_n": coverage_summary(joint_indicators, joint_widths),
            "mean_q_bias": float(np.mean(meanq) - mean_q_from_states(t0)),
        }
        print(f"{name}: bias mean={results[name]['max_bin_bias']['mean']:.4f} "
              f"p95={results[name]['max_bin_bias']['p95']:.4f} "
              f"fixed coverage={results[name]['coverage_fixed_R']['mean']:.3f} "
              f"joint coverage={results[name]['coverage_joint_R_n']['mean']:.3f}", flush=True)
        # Checkpoint the expensive nested-bootstrap results before the shorter
        # operator-only summary below.
        (OUT / "exp5_operator_uncertainty.checkpoint.json").write_text(
            json.dumps(results, indent=2)
        )

    # operator bootstrap (Dirichlet rows) on S0
    print("operator bootstrap ...", flush=True)
    pA = project(R, t0_s0)
    op = []
    for _ in range(N_OP):
        Rstar = draw_operator()
        n_det = rng.multinomial(n_sys, pA)
        pi_star = dagostini_observable_only(Rstar, n_det, n_iter=200)
        op.append(float(np.abs(pi_star - t0_s0).max()))
    op = np.array(op)
    results["operator_bootstrap_S0"] = {
        "n_draws": N_OP,
        "max_bin_bias_mean": float(op.mean()),
        "max_bin_bias_std": float(op.std()),
        "max_bin_bias_p95": float(np.quantile(op, 0.95)),
    }
    results["configuration"] = {
        "n_validation_seeds": n_seed,
        "n_systems_per_seed": n_sys,
        "bootstrap_replicates_per_seed": B,
        "interval_percentiles": [0.16, 0.84],
        "operator_draws_summary": N_OP,
        "rng": "NumPy PCG64",
        "seed": 999,
    }
    print(json.dumps(results["operator_bootstrap_S0"], indent=2))

    (OUT / "exp5_operator_uncertainty.json").write_text(json.dumps(results, indent=2))
    print("saved", OUT / "exp5_operator_uncertainty.json")


if __name__ == "__main__":
    main()
