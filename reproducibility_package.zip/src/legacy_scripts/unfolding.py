"""Unfolding tools: D'Agostini iterative Bayesian unfolding and diagnostics.

Two likelihood formulations:

1. Full-state (oracle) unfolding -- uses the observed counts including the
   NOT_OBSERVED state, i.e. n includes n_NOTOBS.  This is the formulation the
   referee flagged as oracle-assisted for a real catalogue.

2. Observable-only unfolding -- the likelihood is multinomial over the
   *detected* states only:
       p_j(t) = sum_i t_i R_ij / sum_i t_i eps_i,   eps_i = sum_{j in det} R_ij
   with observed counts n_j (j detected only).  This never uses a missing
   count that a real catalogue cannot provide.  Selection efficiency enters
   the likelihood through the normalization but the NOT_OBSERVED count itself
   is not data.
"""

from __future__ import annotations

import numpy as np


def dagostini_full(R: np.ndarray, n: np.ndarray, pi0: np.ndarray | None = None,
                   n_iter: int = 30) -> np.ndarray:
    """D'Agostini unfolding with the full state vector (incl. NOT_OBSERVED).

    R: (n_true, n_obs);  n: (n_obs,);  pi: (n_true,).
    """
    n_true, n_obs = R.shape
    pi = np.full(n_true, 1.0 / n_true) if pi0 is None else pi0.copy()
    for _ in range(n_iter):
        denom = R.T @ pi
        denom[denom <= 0] = 1e-300
        Pt = (R * pi[:, None]) / denom[None, :]      # (n_true, n_obs)
        pi_new = Pt @ n
        s = pi_new.sum()
        if s > 0:
            pi_new = pi_new / s
        pi = pi_new
    return pi


def dagostini_observable_only(R: np.ndarray, n_det: np.ndarray,
                              pi0: np.ndarray | None = None,
                              n_iter: int = 200, tol: float = 1e-10) -> np.ndarray:
    """Observable-only maximum-likelihood unfolding (EM).

    The observed counts n_det over the *detected* states follow a multinomial
    with
        p_j(t) = sum_i t_i R_ij / (sum_i t_i eps_i),   eps_i = sum_{j in det} R_ij
    The EM update (complete data = latent origin of each detected system):
        E-step:  w_ij = t_i R_ij / sum_k t_k R_kj
        M-step:  t_i_new = (sum_j n_j w_ij) / eps_i,  normalized
    This never uses the NOT_OBSERVED count.
    """
    Rd = R[:, :-1]                                    # (n_true, n_det)
    eps = Rd.sum(axis=1)
    eps[eps <= 0] = 1e-12
    n_true, n_det_states = Rd.shape
    n_det = np.asarray(n_det, dtype=float).ravel()
    assert len(n_det) == n_det_states, f"n_det length {len(n_det)} != {n_det_states}"
    pi = np.full(n_true, 1.0 / n_true) if pi0 is None else pi0.copy()
    for _ in range(n_iter):
        denom = Rd.T @ pi                            # (n_det,)
        denom[denom <= 0] = 1e-300
        w = (Rd * pi[:, None]) / denom[None, :]      # (n_true, n_det)
        pi_new = (w @ n_det) / eps
        s = pi_new.sum()
        if s <= 0 or not np.isfinite(s):
            break
        pi_new = pi_new / s
        if np.max(np.abs(pi_new - pi)) < tol:
            pi = pi_new
            break
        pi = pi_new
    return pi


def multinomial_loglike(R: np.ndarray, t: np.ndarray, n_det: np.ndarray) -> float:
    """Multinomial log-likelihood over detected states.

    p_j = sum_i t_i R_ij / sum_i t_i eps_i
    """
    Rd = R[:, :-1]
    eps = Rd.sum(axis=1)
    eps[eps <= 0] = 1e-12
    p = (Rd.T @ t) / (eps @ t)
    p = np.clip(p, 1e-12, 1.0)
    p = p / p.sum()
    return float(n_det @ np.log(p))


def poisson_loglike(R: np.ndarray, t: np.ndarray, n_det: np.ndarray,
                    scale: float | None = None) -> float:
    """Poisson log-likelihood over detected states (rate = scale * sum_i t_i R_ij)."""
    Rd = R[:, :-1]
    rate = Rd.T @ t
    if scale is None:
        scale = n_det.sum() / max(rate.sum(), 1e-12)
    mu = rate * scale
    mu = np.clip(mu, 1e-12, None)
    return float(np.sum(n_det * np.log(mu) - mu))
