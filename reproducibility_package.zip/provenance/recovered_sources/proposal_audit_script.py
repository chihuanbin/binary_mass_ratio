"""Run the formal joint response calibration (200,000 systems).

Per the referee's central requirement (plan items 1-2), the training
population is RESTRICTED to physically allowed main-sequence support:
a system is accepted only if BOTH components (M1 and q*M1) lie on the
phase-0 main sequence of the drawn (age, [Fe/H]) isochrone.  Physically
impossible age-M1 combinations are rejected at draw time and counted
separately; they never enter the latent space of the response operator.

Sampling strategy (efficiency):
  * For each M1 bin we pre-select the clusters whose nominal-age MS upper
    mass (with a +0.3 dex age-scatter margin) covers the bin maximum; only
    those clusters are drawn from, so the age-M1 rejection is minimal.
  * For each (M1 bin, q bin) state we draw a batch, run the forward model,
    drop any residual physically-incompatible systems (counted), and keep
    the rest until the per-state target is reached.

Outputs (arch_code_results/results/):
  calibration_200k.npz   R (54,55), loss decomposition, per-state counts,
                         rejection statistics
  calibration_summary.json
"""

from __future__ import annotations

import json
import sys
from collections import Counter
import hashlib
import time
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src" / "legacy_scripts"))
from mist_loader import load_grid
from cluster_catalogue import ClusterCatalogue
from phot_errors import collect_errors, fit_error_relations, error_model
from forward_model import (ForwardModel, M1_EDGES, Q_EDGES, N_M1, N_Q,
                           N_TRUE, LOSS_NAMES, L_AGE_M1, L_DOMAIN,
                           m1_bin_index, q_bin_index, true_state_index)
from response_matrix import build_response, matrix_stats

DATA = Path("/Users/chihuanbin/CMD_binary_radio/arch_code_results/data")
OUT = Path("/Users/chihuanbin/CMD_binary_radio/pasp_cmd_recoverability_revision/data/derived/proposal_audit")
OUT.mkdir(parents=True, exist_ok=True)

N_PER_STATE = 3704          # 54 * 3704 = 200,016
SEED = 20260829
AGE_SCATTER = 0.15


def main() -> None:
    t0 = time.time()
    grid = load_grid(DATA / "MIST_v1.2_vvcrit0.4_UBVRIplus")
    cat = ClusterCatalogue(DATA / "hunt24" / "params.csv",
                           DATA / "hunt24" / "members_full.dat")
    errs = collect_errors(DATA / "hunt24" / "members_full.dat")
    mg, sig, coefs = fit_error_relations(errs)
    em = error_model(mg, sig)
    fm = ForwardModel(grid, cat, em)
    print(f"[{time.time()-t0:6.1f}s] models loaded", flush=True)

    # pre-select cluster subsets per M1 bin: nominal-age MS upper (a small
    # margin is NOT subtracted; the age scatter is handled by rejection).
    # For bins with no cluster supporting m1_hi (e.g. 4.59-5.0 Msun), fall
    # back to clusters supporting m1_lo: the excess mass range is rejected
    # naturally and counted as age-M1 incompatible.
    clusters = cat.clusters()
    n_cl = len(clusters)
    m1_subsets = []
    for b in range(N_M1):
        m1_lo, m1_hi = M1_EDGES[b], M1_EDGES[b + 1]
        ok_hi = np.zeros(n_cl, dtype=bool)
        ok_lo = np.zeros(n_cl, dtype=bool)
        for i in range(n_cl):
            r = clusters.iloc[i]
            s_nom = fm.ms.mass_support(r["feh"], r["log_age"])
            if s_nom is None:
                continue
            if s_nom[1] >= m1_hi:
                ok_hi[i] = True
            if s_nom[1] >= m1_lo:
                ok_lo[i] = True
        subset = ok_hi if ok_hi.any() else ok_lo
        m1_subsets.append(subset)
        names = clusters.loc[subset, "cluster"].tolist()
        print(f"  M1 bin {b} ({m1_lo:.1f}-{m1_hi:.1f}): "
              f"{subset.sum()} clusters: {names}", flush=True)

    rng = np.random.Generator(np.random.PCG64(SEED))

    m1_acc, q_acc, par_acc, res_acc = [], [], [], []
    n_attempts_total = 0
    n_phys_rejected = 0
    all_first_failures = Counter()
    flag_counts = Counter()

    for b in range(N_M1):
        m1_lo, m1_hi = M1_EDGES[b], M1_EDGES[b + 1]
        subset = m1_subsets[b]
        for qb in range(N_Q):
            q_lo, q_hi = Q_EDGES[qb], Q_EDGES[qb + 1]
            st = b * N_Q + qb
            got = 0
            while got < N_PER_STATE:
                batch = max(N_PER_STATE - got, 4_000)
                par = cat.draw(batch, rng, subset=subset)
                n_attempts_total += batch
                m1 = m1_lo + rng.random(batch) * (m1_hi - m1_lo)
                q = q_lo + rng.random(batch) * (q_hi - q_lo)
                res = fm.simulate_population_vectorized(
                    m1, q, par, seed=int(rng.integers(1 << 30)))
                # Count all generated proposals before quota truncation.
                for code, name in enumerate(LOSS_NAMES):
                    all_first_failures[name] += int(np.count_nonzero(res["loss"] == code))
                all_first_failures["detected"] += int(np.count_nonzero(res["loss"] < 0))
                # Independent multi-label cut flags among rows reaching selection.
                cut_examined = (res["loss"] != L_AGE_M1) & (res["loss"] != L_DOMAIN)
                g_flag = cut_examined & (res["m_obs"][:, 0] > 20.0)
                sig_flag = cut_examined & (np.max(res["sigma"], axis=1) > 0.1)
                nonfinite_flag = cut_examined & ~np.all(np.isfinite(res["m_obs"]), axis=1)
                flag_counts["cut_examined"] += int(cut_examined.sum())
                flag_counts["G_gt_20"] += int(g_flag.sum())
                flag_counts["sigma_max_gt_0p1"] += int(sig_flag.sum())
                flag_counts["G_and_sigma_overlap"] += int((g_flag & sig_flag).sum())
                flag_counts["nonfinite_phot_flag"] += int(nonfinite_flag.sum())
                phys_bad = (res["loss"] == L_AGE_M1) | (res["loss"] == L_DOMAIN)
                n_phys_rejected += int(phys_bad.sum())
                keep = ~phys_bad
                if not keep.any():
                    continue
                m1k, qk = m1[keep], q[keep]
                par_k = par.iloc[np.where(keep)[0]].reset_index(drop=True)
                res_k = {k2: v[keep] if isinstance(v, np.ndarray) else v
                         for k2, v in res.items()}
                t_idx = true_state_index(m1_bin_index(m1k), q_bin_index(qk))
                assert np.all(t_idx == st), "state mismatch in calibration draw"
                take = min(len(m1k), N_PER_STATE - got)
                for i in range(take):
                    m1_acc.append(m1k[i]); q_acc.append(qk[i])
                    par_acc.append((par_k["log_age"].iloc[i], par_k["feh"].iloc[i],
                                    par_k["dist_pc"].iloc[i], par_k["AV"].iloc[i]))
                    res_acc.append((int(res_k["loss"][i]),
                                    res_k["obs_m1"][i], res_k["obs_q"][i]))
                got += take
                n_done = len(m1_acc)
                if n_done % 20_000 < batch:
                    print(f"[{time.time()-t0:6.1f}s] state {st}/54 done={n_done}/"
                          f"{N_TRUE*N_PER_STATE} attempts={n_attempts_total} "
                          f"phys_rej={n_phys_rejected}", flush=True)

    m1 = np.array(m1_acc)
    q = np.array(q_acc)
    loss = np.array([r[0] for r in res_acc])
    om1 = np.array([r[1] for r in res_acc])
    oq = np.array([r[2] for r in res_acc])
    par = np.array(par_acc)

    print("loss decomposition (accepted population):",
          dict(Counter(LOSS_NAMES[l] if l >= 0 else "OBSERVED" for l in loss)),
          flush=True)

    rdict = build_response(loss, om1, oq, m1, q)
    stats = matrix_stats(rdict["R"])

    total = len(loss)
    frac = {name: float((loss == code).mean()) for code, name in enumerate(LOSS_NAMES)}
    frac["observed"] = float((loss < 0).mean())

    summary = {
        "R": rdict["R"],
        "loss_frac_per_state": rdict["loss_frac"],
        "loss_counts": rdict["loss_counts"],
        "n_per_state": rdict["n_per_state"],
        "n_observed": rdict["n_observed"],
        "n_total": rdict["n_total"],
        "loss_names": np.array(rdict["loss_names"]),
        "singular_values": stats["singular_values"],
        "rank": stats["rank"],
        "cond": stats["cond"],
        "sigma_max": stats["sigma_max"],
        "sigma_min": stats["sigma_min"],
        "loss_fraction_population": frac,
        "m1_edges": M1_EDGES,
        "q_edges": Q_EDGES,
        "n_phys_rejected": n_phys_rejected,
        "n_attempts_total": n_attempts_total,
        "phys_rejection_fraction": (n_phys_rejected / n_attempts_total
                                    if n_attempts_total else 0.0),
        "n_per_state_target": N_PER_STATE,
        "seed": SEED,
        "elapsed_s": time.time() - t0,
    }
    n_proposal = int(n_attempts_total)
    n_model_support_rejected = int(all_first_failures["age_M1_incompatible"])
    n_in_support = n_proposal - n_model_support_rejected
    in_support_failures = {k: int(v) for k, v in all_first_failures.items()
                           if k != "age_M1_incompatible"}
    assert sum(in_support_failures.values()) == n_in_support
    assert n_model_support_rejected + n_in_support == n_proposal
    audit = {
        "experiment_id": "P0-LOSS-01", "seed": SEED,
        "N_proposal": n_proposal,
        "N_model_support_rejected": n_model_support_rejected,
        "N_in_support": n_in_support,
        "proposal_stage_denominator_id": "proposal_all_attempted_rows",
        "in_support_stage_denominator_id": "after_age_M1_first_failure_filter",
        "in_support_first_failure_counts": in_support_failures,
        "all_first_failure_counts": {k: int(v) for k,v in all_first_failures.items()},
        "multi_label_flags": {k: int(v) for k,v in flag_counts.items()},
        "old_combined_support_rejection_count": int(n_phys_rejected),
        "old_combined_support_rejection_check": int(all_first_failures["age_M1_incompatible"] + all_first_failures["MIST_domain"]),
        "N_training_accepted_rows": int(len(loss)),
        "training_row_counts": np.bincount(true_state_index(m1_bin_index(m1), q_bin_index(q)), minlength=N_TRUE).tolist(),
        "accounting_pass": True,
        "interpretation": "age_M1_incompatible is an operational rejection by the adopted MIST MS/PMS interpolation support, not proof of physical nonexistence. MIST_domain is counted separately as an in-support first failure. G/sigma are sensitivity-model flags, not calibrated Gaia completeness.",
        "source_sha256": {
            "run_calibration.py": hashlib.sha256(Path("/Users/chihuanbin/CMD_binary_radio/arch_code_results/scripts/run_calibration.py").read_bytes()).hexdigest(),
            "forward_model.py": hashlib.sha256(Path("/Users/chihuanbin/CMD_binary_radio/arch_code_results/scripts/forward_model.py").read_bytes()).hexdigest(),
            "proposal_audit_script.py": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        }
    }
    frozen = np.load("/Users/chihuanbin/CMD_binary_radio/arch_code_results/results/calibration_200k.npz", allow_pickle=True)
    audit["matches_frozen_proposal_total"] = bool(n_proposal == int(frozen["n_attempts_total"]))
    audit["matches_frozen_combined_rejections"] = bool(n_phys_rejected == int(frozen["n_phys_rejected"]) and audit["old_combined_support_rejection_check"] == int(frozen["n_phys_rejected"]))
    audit["restricted_R_max_abs_delta"] = float(np.max(np.abs(rdict["R"] - frozen["R"])))
    audit["restricted_R_matches_frozen"] = bool(np.array_equal(rdict["R"], frozen["R"]))
    audit["accounting_pass"] = bool(audit["accounting_pass"] and audit["matches_frozen_proposal_total"] and audit["matches_frozen_combined_rejections"] and audit["restricted_R_matches_frozen"])
    if not audit["accounting_pass"]:
        raise RuntimeError("event audit does not match frozen run; do not use these counts")
    (OUT / "proposal_audit.json").write_text(json.dumps(audit, indent=2))
    print(json.dumps({k:audit[k] for k in ["N_proposal","N_model_support_rejected","N_in_support","in_support_first_failure_counts","multi_label_flags","restricted_R_matches_frozen","accounting_pass"]}, indent=2), flush=True)
    (OUT / "calibration_summary.json").write_text(json.dumps({"n_total":total,"n_per_state":rdict["n_per_state"].tolist(),"R_shape":list(rdict["R"].shape),"R_max_abs_delta":audit["restricted_R_max_abs_delta"],"proposal_audit_source":"proposal_audit.json"},indent=2))
    json_summary = {k: (v.tolist() if isinstance(v, np.ndarray) else
                        (float(v) if isinstance(v, (np.floating, np.integer)) else v))
                    for k, v in summary.items() if k != "R"}
    (OUT / "calibration_summary.json").write_text(json.dumps(json_summary, indent=2))
    print(json.dumps({k: json_summary[k] for k in
                      ["rank", "cond", "sigma_max", "sigma_min",
                       "loss_fraction_population", "n_observed", "n_total",
                       "phys_rejection_fraction"]}, indent=2))
    print(f"[{time.time()-t0:6.1f}s] done -> {OUT}")


if __name__ == "__main__":
    main()
