# Sampling provenance from archived inputs and frozen-seed replay

- `arch_code_results/data/hunt24/members_full.dat`: 1,291,929 rows. The same file is used in two roles: the photometric error-relation input and the cluster member-count weights used for nuisance-cluster sampling. These roles are not separate catalogues.
- `arch_code_results/data/hunt24/params.csv`: six cluster parameter records: Pleiades, Hyades, NGC 188, Praesepe, M67, and NGC 6791.
- Calibration proposal sampling restricts candidate clusters by the drawn primary-mass interval. The replay printed these eligible subsets:

| M1 interval (Msun) | Cluster subset |
|---|---|
| 1.0–1.5 | Pleiades, Hyades, Praesepe, M67 |
| 1.5–2.0 | Pleiades, Hyades, Praesepe |
| 2.0–2.5 | Pleiades, Hyades, Praesepe |
| 2.5–3.0 | Pleiades, Praesepe |
| 3.0–4.0 | Pleiades |
| 4.0–5.0 | Pleiades |

NGC 188 and NGC 6791 are present in the master table but not in the calibrated M1-dependent subsets. The 200,016 accepted response-training records are quota-stratified over the 54 joint states (3,704 each); they are not a simple random sample of a typical cluster's unresolved binaries. Do not describe N=2,000–5,000 as a typical high-quality single-cluster binary sample without a separate catalogue audit.
