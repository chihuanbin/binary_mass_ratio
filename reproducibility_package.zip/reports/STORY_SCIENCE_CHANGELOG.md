# R7 story/science change log

## What changed

- Reframed the paper around evidence-to-claim matching: specified-test sensitivity, reconstruction error against a fixed uniform output, and marginal coverage are separate estimands.
- Reworked the Introduction to recognize the mock-cluster and real-cluster validation in Li et al. (2020) and Li & Shao (2022), then state the narrower question addressed by this discrete operator benchmark.
- Added the code-matched three-band flux-addition to apparent-photometry bridge and explained that the response aggregates support, nuisance, noise, selection, and inverse-grid effects.
- Reorganized Results around the three evidence classes. Detection-focus and S1 remain distinct: the former downweights one q state; S1 downweights two adjacent q states.
- Made the fixed-uniform comparison visible on the all-realization error figure. The S0 baseline at zero lies on the y-axis; the S1 analytic baseline is 0.0044998269.
- Added two deterministic, frozen-R projections to an appendix. Their probability sums and linear mapping identity were checked to 1e-12. This is labeled `ADDED_DETERMINISTIC_DIAGNOSTIC`; it is not Monte Carlo evidence.
- Moved proposal event counts and unresolved quota linkage to an appendix. No third quota stage was inferred from the 45,598 arithmetic difference.
- Added `docs/USING_BENCHMARK.md`, a claim/evidence/scope CSV, and current reproduction-level descriptions.

## Scientific quantities and identities

Core Monte Carlo results, truth vectors, seeds, thresholds, response matrix, sample sizes, and iteration limits were not changed. No new scientific Monte Carlo was performed. The plotted reconstruction data still use all 20 outer realizations for each truth; no unrecorded per-realization mean-q series or interval endpoints were generated. The archived conditional results are described as finite-iteration estimates, not convergence-screened fits.

## Remaining limits

The proposal-to-quota link remains unresolved. Raw-to-response reproduction is `NOT_RUN`. The focused LR null check is not full-grid validation; full 672-cell bitwise reproduction is not claimed. The response and inverse fit remain conditional on their stated support/nuisance/noise/selection design and true nuisance values. Author metadata remains `AWAITING_AUTHOR`. The revision strengthens interpretation and use instructions; it does not prove novelty, universal recoverability, or acceptance by a journal.
