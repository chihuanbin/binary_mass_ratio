# R7 final status

Run ID: `R7_STORY_20260927`  
Scope: story, scientific interpretation, figures, deterministic projection diagnostic, and reproducibility documentation for the existing PASP benchmark.

## Outcome

- **Execution:** COMPLETE for the authorized R7 scope.
- **Core numerical results changed:** NO. Existing truth vectors, response, seeds, thresholds, sample sizes, iteration budgets, and archived inference outputs were not changed.
- **New scientific Monte Carlo experiments:** NO.
- **Deterministic diagnostic:** COMPUTED. `ADDED_DETERMINISTIC_DIAGNOSTIC`; two predefined contrasts only, using the frozen unit-efficiency response. Inputs, code, residual checks, and outputs are in `data/derived/r7_feature_projection/`.
- **Story restructuring:** COMPLETE. The manuscript now distinguishes test sensitivity, reconstruction relative to a fixed uniform output, and marginal interval coverage; experiment identities and scopes are explicit.
- **Physical/statistical interpretation:** Strengthened and bounded. The forward flux chain, global normalization effect, conditional inverse fit, distinct estimands, test-specific interpretation, and practical guidance are stated. Grid, finite iteration, nuisance, and selection mechanisms are not assigned unique causal responsibility.
- **Literature positioning:** VERIFIED for the references cited in the manuscript according to the existing R4 primary-source/reference audit. Bibliography contents were not changed in R7.
- **Figure/data consistency:** CHECKED. Figure 1 uses the frozen response; Figure 2 retains the accepted current 56-cell result; Figure 3 shows all 20 archived realizations and analytic fixed-uniform reference errors; Figure 4 derives from the two specified contrast vectors; Figure 5 uses the restricted proposal counts and explicitly leaves quota linkage unresolved. Figure numbering and citations are continuous.
- **Reproduction scope:** Derived-artifact regeneration is documented and packaged. The deterministic diagnostic has a runnable command and smoke checks. Full frozen-operator conditional replay is NOT_CLAIMED; raw-input-to-response rebuild is NOT_RUN. Proposal accounting is count-summary only; event-to-quota linkage remains UNRESOLVED. The full 672-cell LR grid is not claimed as bitwise reproduced; three two-q-bin discrepancies remain documented.
- **Author metadata:** AWAITING_AUTHOR; no author, affiliation, corresponding-author, funding, or anonymity fields were changed.
- **PDF visual review:** PASS, all 10 pages rendered and inspected after the final build. One 9.03-pt TeX overfull warning at the Introduction heading/line-number boundary is not visibly colliding with text.
- **Submission stage:** AUTHOR_REVIEW_REQUIRED. No submission, public release, or DOI was made.

## Build and visual evidence

Final source: `manuscript/main.tex`  
Final bibliography: `manuscript/references.bib`  
Final PDF: `manuscript/main.pdf`  
Build command and output: `cd manuscript && latexmk -g -pdf -interaction=nonstopmode -halt-on-error main.tex`; `reports/R7_latexmk.log`  
Page render and review: `pdftoppm -png -r 110 manuscript/main.pdf /private/tmp/pasp_r7_finalqa_page`; `reports/R7_visual_review.md`

Final SHA256 values are recorded in `reports/R7_PACKAGE_SHA256.txt` for the manuscript, bibliography, PDF, release manifest, and ZIP.

## Scientific boundary

The benchmark supports conclusions only for its discrete response, support conditioning, nuisance sampling, selection cuts, inverse-fit conditions, tested truths, alternatives, and interval procedures. It does not establish a universal recoverability boundary, external Gaia completeness, real-cluster binary structure, an algorithm ranking, or a general theorem.
