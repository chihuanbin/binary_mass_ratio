# R7 final PDF visual review

- PDF: `manuscript/main.pdf`, final TeX build, 10 US-letter pages.
- Render command: `pdftoppm -png -r 110 manuscript/main.pdf /private/tmp/pasp_r7_finalqa_page`.
- All ten final page renders were opened and inspected after the final compilation.
- Page 1: title/author block, abstract, keywords, and Introduction are readable; keyword line no longer wraps a compound keyword.
- Page 2: flux-addition equations, distance/extinction ordering and nuisance-model text fit within the text block.
- Pages 3–4: response equations and Figure 1 are legible; state blocks and missing column are visible.
- Page 5: Figure 2 uses one shared scale and its two focus annotations align with the w=0.75 row; caption and subsequent interpretation do not overlap.
- Pages 6–7: coverage definitions, Table 1, all 20 reconstruction realizations, and the fixed-uniform baselines are legible. S0's baseline is at zero on the y-axis and explicitly identified; S1's 0.00450 line is visible.
- Pages 8–10: Discussion/conclusions, the added two-contrast projection figure, restricted proposal accounting, and reference list are readable. Figure 4 and Figure 5 do not overlap text or references. Figure numbering is continuous and both appendix figures are cited.
- Reference-page spot check: Choi et al. shows `ApJ, 823, 102`; D’Agostini shows `arXiv:1010.0632`.
- No clipped figure, broken reference, missing graphic, or figure/caption overlap was seen. Figure 6's historical role (now Figure 5) remains quota-link-limited and is described accordingly.
- TeX retains one 9.03-pt overfull warning at the `Introduction` section-heading/line-number boundary. It is not a keyword or body-text overflow and no visible collision appears in the rendered page.

Status: **PASS** for visual layout of the final built PDF. This is a visual/layout check, not scientific validation of untested assumptions.
