# R4 reference and claim audit

Status: **VERIFIED for the references cited in the revised manuscript**. Bibliographic identity and claim support were checked separately. Legacy unused entries are not counted as cited support. The NGC 6253 Chi et al. entry is no longer cited; the PASJ 77, 1050 article is cited for its explicit BASE-9 analysis of cluster parameters, individual initial masses, and binary mass ratios.

| Key | Manuscript use | Bibliographic check | Claim-support check |
|---|---|---|---|
| `Chi2025a` | Introduction, Gaia DR3 cluster inference | **VERIFIED** against Oxford Academic, PASJ 77(5), 1050–1064, DOI 10.1093/pasj/psaf082 | **VERIFIED**: §2.3 describes BASE-9/PARSEC inference of cluster parameters and posterior individual initial masses and binary mass ratios. The manuscript states only this use. |
| `Choi2016` | MIST model provenance | **VERIFIED**: six authors, ApJ 823, 102, DOI 10.3847/0004-637X/823/2/102 | **VERIFIED**: official MIST citation page requests Choi et al. 2016; the local code selects the MIST v1.2 product. |
| `Dotter2016` | MIST isochrone methods | **REUSED_VERIFIED** from R3 record audit and official MIST citations page | **VERIFIED** for general MIST model construction, not a substitute for the local v1.2 file/product identity. |
| `Riello2021` | Gaia EDR3 $G,G_{BP},G_{RP}$ photometric columns | **VERIFIED**: A&A 649, A3, DOI 10.1051/0004-6361/202039587 | **VERIFIED** for Gaia EDR3 photometric content/validation. |
| `Gaia2023` | Gaia DR3 member-table data release | **VERIFIED**: A&A 674, A1, DOI 10.1051/0004-6361/202243940 | **VERIFIED** for DR3 release provenance. ESA documentation states DR3 broad-band photometry is the EDR3 photometry; the paper does not claim catalogue completeness calibration. |
| `Hunt2024` | Cluster catalogue and member table | **REUSED_VERIFIED** from R3 primary A&A audit | **VERIFIED** for input catalogue provenance; local code documents how member counts/fluxes are used here. |
| `Netopil2016` | Cluster metallicity compilation | **REUSED_VERIFIED** from R3 primary A&A audit | **VERIFIED** for the cited homogenized compilation; local code documents the adopted field. |
| `DAgostini2010` | Observable-only iterative unfolding context | **VERIFIED** against author-hosted arXiv:1010.0632 | **VERIFIED** as methodological context. It is cited as an arXiv/workshop contribution, not represented as a journal article. The paper's actual efficiency-adjusted update is printed in the Methods. |
| `Efron1979` | Resampling background for realization-cluster bootstrap | **VERIFIED**: Annals of Statistics 7(1), 1–26, DOI 10.1214/aos/1176344552 | **VERIFIED** as the general bootstrap source; the actual resampling unit and percentile algorithm are specified locally. |
| `Li2020`, `Li2022`, `Duchene2013`, `Raghavan2010` | CMD binary-mixture context and multiplicity motivation | **REUSED_VERIFIED** from R3 source audit | **VERIFIED** for the limited contextual statements retained in the Introduction. |

## Scope corrections

- `Chi2025a` is now connected to the paper's stated Bayesian mass/q inference content, rather than cited merely as a Gaia catalogue example.
- The unverified-for-this-round Chi et al. NGC 6253 reference has been removed from the cited prose and bibliography; the reference set no longer depends on that partially checked record.
- Gaia EDR3 is identified as the MIST photometric system, while Gaia DR3 supplies the catalogue member flux/error data used to fit this benchmark's noise curves. The manuscript explicitly says those fitted curves are not a Gaia completeness calibration.
- No reference is offered as evidence that the current simulation matches real Gaia catalogue inclusion probabilities.

## Primary-record links

- Chi et al. (2025), PASJ 77, 1050: https://academic.oup.com/pasj/article/77/5/1050/8236289
- Official MIST reference list: https://mist.science/references.html
- Choi et al. (2016), author-hosted preprint: https://arxiv.org/abs/1604.08592
- Gaia DR3 documentation: https://gea.esac.esa.int/archive/documentation/GDR3/
- Riello et al. (2021), DOI record: https://doi.org/10.1051/0004-6361/202039587
- D'Agostini (2010), author-hosted preprint: https://arxiv.org/abs/1010.0632
- Efron (1979), DOI record: https://doi.org/10.1214/aos/1176344552
