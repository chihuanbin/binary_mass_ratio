from pathlib import Path
import csv, json, hashlib
import numpy as np
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'data/derived/legacy_results/exp5_operator_uncertainty.json'
z=json.loads(source.read_text())
OUT=ROOT/'data/derived'
with (OUT/'reconstruction_seed_results.csv').open('w',newline='') as f:
    w=csv.writer(f); w.writerow(['population','seed_id','E_t_s_max_abs_latent_fraction_error','fixed_R_point_coverage','fixed_R_all_54_contained','joint_R_n_point_coverage','joint_R_n_all_54_contained'])
    for pop in ('S0','S1'):
        a=z[pop]
        for i,(err,cf,cj) in enumerate(zip(a['max_bin_bias']['all'],a['coverage_fixed_R']['per_seed'],a['coverage_joint_R_n']['per_seed']),1):
            w.writerow([pop,i,err,cf,int(cf==1),cj,int(cj==1)])
with (OUT/'reconstruction_summary.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['population','n_seeds','N_per_seed','mean_Delta_q','mean_E_t_s','point_coverage_fixed_R_k','point_coverage_fixed_R_n','point_coverage_fixed_R','seed_cluster_bootstrap_low','seed_cluster_bootstrap_high','all54_fixed_R_k','all54_fixed_R_n','point_coverage_joint_R_n_k','point_coverage_joint_R_n_n','point_coverage_joint_R_n','seed_cluster_bootstrap_joint_low','seed_cluster_bootstrap_joint_high','all54_joint_k','all54_joint_n'])
    for pop in ('S0','S1'):
        a=z[pop]; cf=a['coverage_fixed_R']; cj=a['coverage_joint_R_n']
        w.writerow([pop,20,20000,a['mean_q_bias'],a['max_bin_bias']['mean'],cf['successes'],cf['trials'],cf['mean'],*cf['cluster_seed_bootstrap_95'],cf['simultaneous_all_bins']['successes'],cf['simultaneous_all_bins']['trials'],cj['successes'],cj['trials'],cj['mean'],*cj['cluster_seed_bootstrap_95'],cj['simultaneous_all_bins']['successes'],cj['simultaneous_all_bins']['trials']])
fig,axs=plt.subplots(1,2,figsize=(7.1,3.2),constrained_layout=True)
colors={'S0':'#376b8c','S1':'#c0603e'}
for ax,pop in zip(axs,('S0','S1')):
    a=z[pop]; e=np.asarray(a['max_bin_bias']['all']); cf=np.asarray(a['coverage_fixed_R']['per_seed']); cj=np.asarray(a['coverage_joint_R_n']['per_seed'])
    ax.scatter(np.arange(1,21),e,s=18,color=colors[pop],label=r'$E_{t,s}=\max_i|\hat t_{s,i}-t_i|$')
    # The data-independent uniform estimator is an analytic reference, not a
    # fitted or realization-specific baseline.  Its zero for S0 coincides
    # exactly with the lower axis boundary and is not visually displaced.
    baseline = 0.0 if pop == 'S0' else 0.004499826929733472
    ax.axhline(baseline, color='#333333', linestyle='--', linewidth=.9,
               label=f'fixed-uniform output: $E_t={baseline:.5f}$')
    ax.set(xlim=(.2,20.8),ylim=(0,.021),xlabel='Independent validation realization',ylabel='Maximum absolute latent-fraction error')
    ax.set_title(f'{pop}: mean $E_{{t,s}}$={e.mean():.4f}; mean $\\Delta_q$={a["mean_q_bias"]:+.4f}',fontsize=9)
    ax.set_xticks([1,5,10,15,20]);ax.tick_params(labelsize=7)
fig.suptitle('All 20 validation realizations; dashed lines are analytic fixed-uniform errors',fontsize=9)
axs[0].text(.03,.035,'S0 baseline = 0; lies on y-axis',transform=axs[0].transAxes,
            va='bottom',ha='left',fontsize=6.5,
            bbox={'facecolor':'white','edgecolor':'none','pad':1.2})
for ax in axs: ax.legend(frameon=False,fontsize=6.5,loc='upper right')
fig.savefig(ROOT/'figures/reconstruction_all_seeds.pdf',bbox_inches='tight');fig.savefig(ROOT/'figures/reconstruction_all_seeds.svg',bbox_inches='tight');plt.close(fig)
manifest={'source':'data/derived/legacy_results/exp5_operator_uncertainty.json','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'script':'scripts/export_reconstruction_results.py','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'outputs':{'figures/reconstruction_all_seeds.pdf':hashlib.sha256((ROOT/'figures/reconstruction_all_seeds.pdf').read_bytes()).hexdigest(),'figures/reconstruction_all_seeds.svg':hashlib.sha256((ROOT/'figures/reconstruction_all_seeds.svg').read_bytes()).hexdigest(),'data/derived/reconstruction_seed_results.csv':hashlib.sha256((OUT/'reconstruction_seed_results.csv').read_bytes()).hexdigest(),'data/derived/reconstruction_summary.csv':hashlib.sha256((OUT/'reconstruction_summary.csv').read_bytes()).hexdigest()},'scope':'Derived from archived realization-level E_t,s and marginal coverage; per-state error vectors and interval endpoints are not archived, so B_t and realization-level Delta_q cannot be recomputed. Per-fit convergence states are also absent.','validation_realizations':20,'systems_per_realization':20000,'fixed_uniform_baseline_E_t':{'S0':0.0,'S1':0.004499826929733472},'figure_reference_lines':'Analytic fixed-uniform E_t in each panel; S0 value 0 coincides with the y-axis and is not displaced.','interval_definition':'marginal 16th-84th percentiles from 1000 count-bootstrap estimates; fixed-response or count bootstrap with Dirichlet response perturbations'}
(OUT/'reconstruction_results.source.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
