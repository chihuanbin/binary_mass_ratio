"""Append a preregistered-as-procedure, post hoc independent null check.

This is an R2 addition, not a pre-registered analysis. It evaluates the single
published focus cell at N=20,000 on the archived frozen restricted operator.
"""
from pathlib import Path
import json, hashlib
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'data/derived/legacy_results'
OUT=ROOT/'data/derived/lr_null_validation.json'
N=20_000; B=10_000; SEED=2026092701; ALPHA=.05
AMP=.75; WIDTH=1; SUPPORT=(3,)

def wilson(k,n):
    z=1.959963984540054; p=k/n; d=1+z*z/n
    c=(p+z*z/(2*n))/d; h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [float(c-h),float(c+h)]

def main():
    rfile=RES/'calibration_200k.npz'; pfile=RES/'exp34_power_surface.npz'; lfile=RES/'exp_lr_power_surface.npz'
    R=np.asarray(np.load(rfile,allow_pickle=True)['R'],float); Rd=R[:,:-1]; eps=Rd.sum(1)
    def project(t):
        p=Rd.T@t/(eps@t); return p/p.sum()
    tA=np.full((6,9),1/54)
    tB=tA.copy(); tB[3,3]*=AMP; tB/=tB.sum()
    pA=project(tA.ravel()); pB=project(tB.ravel())
    pear=np.load(pfile,allow_pickle=True); lr=np.load(lfile,allow_pickle=True)
    pear_cut=float(pear['thresh'].item()[str(N)])
    lr_cut=float(lr['thresholds'].item()[f'{N}|{AMP}|{WIDTH}|(3,)'])
    # Frozen rules: both statistics reject only when strictly greater than cut.
    rng=np.random.default_rng(SEED); counts=rng.multinomial(N,pA,size=B)
    pear_stats=np.sum(((counts/N-pA)**2)/np.maximum(pA,1e-12),axis=1)
    logratio=np.zeros_like(pA); active=(pA>0)&(pB>0)
    logratio[active]=np.log(pB[active]/pA[active]); logratio[(pA==0)&(pB>0)]=np.inf
    lr_stats=counts@logratio
    kp=int(np.count_nonzero(pear_stats>pear_cut)); kl=int(np.count_nonzero(lr_stats>lr_cut))
    out={'status':'NEW_EXECUTION_POST_HOC_R2_ADDITION','scope':'single focus cell only; not whole-grid size validation',
         'N':N,'n_null':B,'seed':SEED,'alpha_target':ALPHA,
         'pA_sha256':hashlib.sha256(np.asarray(pA,dtype='<f8').tobytes()).hexdigest(),
         'alternative':{'q_interval':[.4,.5],'q_width':.1,'M1_interval_Msun':[2.5,3.0],
                        'relative_weight':AMP,'normalization':'global after downweighting; not a fraction/depth'},
         'pB_sha256':hashlib.sha256(np.asarray(pB,dtype='<f8').tobytes()).hexdigest(),
         'R_sha256':hashlib.sha256(np.asarray(R,dtype='<f8').tobytes()).hexdigest(),
         'response_npz_sha256':hashlib.sha256(rfile.read_bytes()).hexdigest(),
         'threshold_source_sha256':{'Pearson':hashlib.sha256(pfile.read_bytes()).hexdigest(),'LR':hashlib.sha256(lfile.read_bytes()).hexdigest()},
         'truth_A_54_state_fractions':tA.ravel().tolist(),'truth_B_54_state_fractions':tB.ravel().tolist(),
         'pA_detected_probabilities':pA.tolist(),'pB_detected_probabilities':pB.tolist(),
         'count_vectors_shared':True,'thresholds_frozen_from_original_independent_2000_null_draws':True,
         'reject_rule':'statistic > frozen empirical 95th percentile; equality does not reject',
         'pearson':{'threshold':pear_cut,'rejections':kp,'rate':kp/B,'wilson95':wilson(kp,B)},
         'simple_vs_simple_LR':{'statistic':'sum_j n_j log(pB_j/pA_j)','threshold':lr_cut,'rejections':kl,'rate':kl/B,'wilson95':wilson(kl,B)},
         'interval_conditioning':'Intervals are conditional on the frozen R and thresholds; threshold recalibration uncertainty is excluded.',
         'inputs':{'R':'data/derived/legacy_results/calibration_200k.npz','pearson':'data/derived/legacy_results/exp34_power_surface.npz','LR':'data/derived/legacy_results/exp_lr_power_surface.npz'}}
    OUT.write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
