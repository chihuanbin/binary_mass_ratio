"""Recompute summaries and the fixed-uniform analytic baseline from archived artifacts.

This script does not generate new simulated data or rerun the nested bootstrap.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DERIVED = ROOT / "data" / "derived"
LEGACY = DERIVED / "legacy_results"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


truth_path = DERIVED / "reconstruction_truth_54state.csv"
truth_rows = list(csv.DictReader(truth_path.open()))
if len(truth_rows) != 54:
    raise ValueError(f"Expected 54 truth rows, received {len(truth_rows)}")
s0 = np.array([float(r["t_S0"]) for r in truth_rows])
s1 = np.array([float(r["t_S1"]) for r in truth_rows])
q_center = np.array([float(r["q_center"]) for r in truth_rows])
uniform = np.full(54, 1.0 / 54.0)
expected_s0 = uniform.copy()
expected_s1 = uniform.copy().reshape(6, 9)
expected_s1[3, 3:5] *= 0.75
expected_s1 = expected_s1.ravel() / expected_s1.sum()
if not np.array_equal(s0, expected_s0):
    raise ValueError("Stored S0 truth does not equal the defined uniform vector")
if not np.array_equal(s1, expected_s1):
    raise ValueError("Stored S1 truth does not equal its archived two-state dip definition")

result_path = LEGACY / "exp5_operator_uncertainty.json"
source_code = ROOT / "src" / "legacy_scripts" / "exp5_operator_uncertainty.py"
unfold_code = ROOT / "src" / "legacy_scripts" / "unfolding.py"
results = json.loads(result_path.read_text())
summary_csv = list(csv.DictReader((DERIVED / "reconstruction_summary.csv").open()))
summary_by_pop = {r["population"]: r for r in summary_csv}

summary = {}
for name, truth in (("S0", s0), ("S1", s1)):
    item = results[name]
    e_values = np.asarray(item["max_bin_bias"]["all"], dtype=float)
    fixed = item["coverage_fixed_R"]
    response_perturbed = item["coverage_joint_R_n"]
    if len(e_values) != 20 or len(fixed["per_seed"]) != 20 or len(response_perturbed["per_seed"]) != 20:
        raise ValueError(f"Expected 20 archived realizations for {name}")
    fixed_seed_counts = np.rint(np.asarray(fixed["per_seed"]) * 54).astype(int)
    perturbed_seed_counts = np.rint(np.asarray(response_perturbed["per_seed"]) * 54).astype(int)
    if not np.allclose(np.asarray(fixed["per_seed"]) * 54, fixed_seed_counts, atol=1e-12):
        raise ValueError(f"Fixed-response per-seed summaries are not integer 54-state counts for {name}")
    if not np.allclose(np.asarray(response_perturbed["per_seed"]) * 54, perturbed_seed_counts, atol=1e-12):
        raise ValueError(f"Response-perturbed per-seed summaries are not integer 54-state counts for {name}")
    if int(fixed_seed_counts.sum()) != int(fixed["successes"]):
        raise ValueError(f"Fixed-response coverage count mismatch for {name}")
    if int(perturbed_seed_counts.sum()) != int(response_perturbed["successes"]):
        raise ValueError(f"Response-perturbed coverage count mismatch for {name}")
    csv_row = summary_by_pop[name]
    if not np.isclose(e_values.mean(), float(csv_row["mean_E_t_s"]), rtol=0, atol=1e-15):
        raise ValueError(f"Re-exported mean E_t_s mismatch for {name}")
    if not np.isclose(item["mean_q_bias"], float(csv_row["mean_Delta_q"]), rtol=0, atol=1e-15):
        raise ValueError(f"Re-exported mean Delta_q mismatch for {name}")
    if int(fixed_seed_counts.sum()) != int(csv_row["point_coverage_fixed_R_k"]):
        raise ValueError(f"Re-exported fixed coverage mismatch for {name}")
    if int(perturbed_seed_counts.sum()) != int(csv_row["point_coverage_joint_R_n_k"]):
        raise ValueError(f"Re-exported response-perturbed coverage mismatch for {name}")

    uniform_error = float(np.max(np.abs(uniform - truth)))
    uniform_delta_q = float(uniform @ q_center - truth @ q_center)
    summary[name] = {
        "n_realizations": len(e_values),
        "N_per_realization": 20000,
        "mean_E_t_s_recomputed": float(e_values.mean()),
        "mean_Delta_q_archived_aggregate": float(item["mean_q_bias"]),
        "fixed_response_coverage_count_recomputed": int(fixed_seed_counts.sum()),
        "fixed_response_coverage_denominator": 20 * 54,
        "fixed_response_per_realization_counts": fixed_seed_counts.tolist(),
        "fixed_response_seed_cluster_interval_archived": fixed["cluster_seed_bootstrap_95"],
        "response_perturbed_coverage_count_recomputed": int(perturbed_seed_counts.sum()),
        "response_perturbed_coverage_denominator": 20 * 54,
        "response_perturbed_per_realization_counts": perturbed_seed_counts.tolist(),
        "response_perturbed_seed_cluster_interval_archived": response_perturbed["cluster_seed_bootstrap_95"],
        "all_54_containment_fixed_response": fixed["simultaneous_all_bins"]["successes"],
        "all_54_containment_response_perturbed": response_perturbed["simultaneous_all_bins"]["successes"],
        "fixed_uniform_E_t": uniform_error,
        "fixed_uniform_Delta_q": uniform_delta_q,
        "truth_q_mean": float(truth @ q_center),
    }

# Reconstruct C only from the archived full-precision response and row sizes;
# the archive does not contain a separate integer confusion-count matrix.
cal_path = LEGACY / "calibration_200k.npz"
with np.load(cal_path, allow_pickle=True) as cal:
    response = np.asarray(cal["R"], dtype=float)
    n_per_state = np.asarray(cal["n_per_state"], dtype=int)
if response.shape != (54, 55) or not np.all(n_per_state == 3704):
    raise ValueError("Unexpected archived calibration dimensions or row sample sizes")
c_float = response * n_per_state[:, None]
c_int = np.rint(c_float).astype(np.int64)
if np.max(np.abs(c_float - c_int)) > 1e-8:
    raise ValueError("Response-derived Dirichlet parameters do not resolve to integer counts")
if not np.all(c_int.sum(axis=1) == 3704):
    raise ValueError("Rounded integer row counts do not preserve calibration row totals")

out = {
    "run_id": "R4_20260927T054256Z",
    "execution_scope": "summary recomputation and analytic fixed-uniform comparison only; no new simulation or bootstrap rerun",
    "definitions": {
        "E_t_s": "max_i |t_hat_{s,i} - t_true_i|, then averaged over the 20 archived realizations",
        "Delta_q": "estimated q-bin-center population mean minus true q-bin-center population mean; only the archived aggregate is retained",
        "point_coverage": "per-realization count of covered marginal states, summed over 20 realizations; the realization-level counts are retained in this output",
        "fixed_uniform": "t_i=1/54 for both populations; analytic estimator does not use observed data",
    },
    "populations": summary,
    "response_count_precision_check": {
        "source": "data/derived/legacy_results/calibration_200k.npz",
        "separate_integer_count_array_in_archive": False,
        "reconstruction": "C = 3704 * full_precision_R, rounded only after checking distance to integer",
        "max_absolute_distance_to_integer": float(np.max(np.abs(c_float - c_int))),
        "integer_total": int(c_int.sum()),
        "row_totals_unique": np.unique(c_int.sum(axis=1)).tolist(),
        "zero_count_cells_including_missing": int((c_int == 0).sum()),
        "missing_column_zero_in_archived_R": bool(np.all(response[:, -1] == 0)),
    },
    "cluster_bootstrap": {
        "status": "archived output reused; not independently rerun",
        "unit": "20 independent validation realizations",
        "replicates": 20000,
        "seed_scheme": "NumPy PCG64 seed=999 shared sequential generator in the archived experiment",
        "interval": "percentile 2.5th and 97.5th quantiles of resampled realization means",
        "source_hashes": {
            "experiment_code": sha(source_code),
            "unfolding_code": sha(unfold_code),
            "experiment_output": sha(result_path),
            "calibration_npz": sha(cal_path),
        },
    },
    "iteration_diagnostics": {
        "method_source_available": True,
        "per_fit_iteration_counts_or_convergence_flags_archived": False,
        "reported_values": "the vectors returned by the archived implementation; the JSON does not identify tolerance convergence versus 200-iteration cap or early numeric stop",
        "limit": "interval endpoints and per-fit convergence/failure states cannot be audited or regenerated from retained artifacts",
    },
}
out_path = DERIVED / "r4_evidence_recomputation.json"
out_path.write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps({"output": str(out_path), "sha256": sha(out_path), "populations": summary,
                  "count_precision": out["response_count_precision_check"],
                  "iteration_diagnostics": out["iteration_diagnostics"]}, indent=2))
