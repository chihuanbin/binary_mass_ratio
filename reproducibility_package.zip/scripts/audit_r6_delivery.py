"""Non-mutating manuscript and source-identity audit for the R6 review supplement."""
from pathlib import Path
import csv, hashlib, json, re
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
tex=(ROOT/'manuscript/main.tex').read_text()
bib=(ROOT/'manuscript/references.bib').read_text()
keys=set(re.findall(r'@\w+\s*\{\s*([^,\s]+)',bib))
cites=set()
for body in re.findall(r'\\cite\w*\s*(?:\[[^]]*\]\s*)*\{([^}]*)\}',tex):
    cites.update(x.strip() for x in body.split(','))
missing_cites=sorted(cites-keys)
labels=set(re.findall(r'\\label\{((?:fig|tab):[^}]+)\}',tex))
refs=set()
for body in re.findall(r'\\(?:ref|autoref|cref|Cref)\{((?:fig|tab):[^}]+)\}',tex): refs.add(body)
missing_refs=sorted(labels-refs)
missing_targets=[]
for target in re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}',tex):
    if not (ROOT/'manuscript'/target).resolve().is_file(): missing_targets.append(target)
internal_hits=sorted(set(re.findall(r'(?i)reviewer|response to reviewers|not submission.ready|R[0-9]_FINAL_STATUS|审稿回复',tex)))

lr_npz=ROOT/'data/derived/legacy_results/exp_lr_power_surface.npz'
lr_json=ROOT/'data/derived/legacy_results/exp_lr_power_surface.json'
with np.load(lr_npz,allow_pickle=True) as z: grid={k:z[k] for k in z.files}
js=json.loads(lr_json.read_text())
assert tuple(grid['power'].shape)==(6,7,2,8)
assert np.array_equal(grid['power'],np.asarray(js['power']))
assert np.array_equal(grid['k_alt'],np.asarray(js['rejections']))
assert int(grid['n_mc'])==2000 and int(grid['seed'])==20260927
lr_source=(ROOT/'scripts/run_likelihood_ratio_benchmark.py').read_text()
assert "exp_lr_power_surface.npz" in lr_source and 'ta>cut' in lr_source
proposal=json.loads((ROOT/'data/derived/proposal_audit/proposal_audit.json').read_text())
expected='e39b59197bb2447139758404ae7ade7e4a2a533c737f5dd97ede65fec505bded'
actual=hashlib.sha256((ROOT/'scripts/run_calibration_event_audit.py').read_bytes()).hexdigest()
assert actual==expected==proposal['source_sha256']['proposal_audit_script.py']
assert hashlib.sha256((ROOT/'provenance/recovered_sources/proposal_audit_script.py').read_bytes()).hexdigest()==expected
figure_rows=list(csv.DictReader((ROOT/'figures/figure2_cell_map.csv').open()))
lr_fig=sum(r['test']=='LR' for r in figure_rows)
assert lr_fig==56
original=ROOT.parent/'draft_Proof_hi.pdf'
original_sha=hashlib.sha256(original.read_bytes()).hexdigest()
assert original_sha=='85348d7e8564db5d55675d419db10f01ea88257413cd88935ff57954b7246cc6'
checks={
 'cited_keys':len(cites),'bibliography_keys':len(keys),'missing_citations':missing_cites,
 'figure_table_labels':sorted(labels),'labels_without_text_references':missing_refs,
 'missing_graphics':missing_targets,'internal_response_residue':internal_hits,
 'LR_archived_shape':list(grid['power'].shape),'LR_JSON_NPZ_exact_agreement':True,
 'LR_generator_sha256':hashlib.sha256((ROOT/'scripts/run_likelihood_ratio_benchmark.py').read_bytes()).hexdigest(),
 'figure2_lr_cells':lr_fig,'proposal_script_sha256_matches_json':actual,
 'original_draft_pdf_sha256_verified':original_sha,
 'selection_limitation_present':bool(re.search(r'completeness|selection function|selection model',tex,re.I)),
 'conditional_nuisance_limitation_present':bool(re.search(r'conditions on true nuisance|nuisance-parameter conditioning|true nuisance',tex,re.I)),
 'finite_operator_scope_present':bool(re.search(r'finite operator|general recoverability|universal response',tex,re.I)),
 'external_control_limit_present':bool(re.search(r'do not compare the operator against an external catalogue or control sample',tex,re.I)),
 'spatial_selection_limit_present':bool(re.search(r'do not model spatially varying or non-axisymmetric membership or completeness',tex,re.I))}
print(json.dumps(checks,indent=2))
if missing_cites or missing_refs or missing_targets or internal_hits: raise SystemExit(1)
