"""Validate exact event-level two-stage loss counts; rounded fractions are refused."""
import csv,sys,re
from pathlib import Path
FIELDS=['stage','category','count','denominator_id','denominator_count','source_hash']
def validate(path):
 with Path(path).open(newline='') as f:
  r=csv.DictReader(f)
  if r.fieldnames!=FIELDS: raise ValueError(f'expected columns {FIELDS}')
  rows=list(r)
 if not rows: raise ValueError('empty table: integer event counts required')
 for i,x in enumerate(rows,2):
  if not x['count'].isdigit() or not x['denominator_count'].isdigit(): raise ValueError(f'row {i}: counts must be nonnegative integers')
  if not re.fullmatch(r'[0-9a-f]{64}',x['source_hash']): raise ValueError(f'row {i}: source_hash must be SHA256')
  if not x['denominator_id']: raise ValueError(f'row {i}: denominator_id required')
 groups={}
 for x in rows: groups.setdefault(x['stage'],[]).append(x)
 if set(groups)!={'proposal','in_support'}: raise ValueError('expected proposal and in_support stages')
 for stage,rs in groups.items():
  ids={x['denominator_id'] for x in rs}; dens={int(x['denominator_count']) for x in rs}; hashes={x['source_hash'] for x in rs}
  if len(ids)!=1 or len(dens)!=1 or len(hashes)!=1: raise ValueError(f'{stage}: inconsistent denominator or source hash')
  if sum(int(x['count']) for x in rs)!=next(iter(dens)): raise ValueError(f'{stage}: first-failure counts do not conserve the denominator')
  cats={x['category'] for x in rs}
  if stage=='proposal' and cats!={'support_rejected','in_support'}: raise ValueError('proposal stage needs support_rejected and in_support only')
  if stage=='in_support' and 'support_rejected' in cats: raise ValueError('support rejection cannot enter the observation-loss stage')
  if stage=='in_support' and 'detected' not in cats: raise ValueError('in_support stage needs detected category')
 if int(groups['proposal'][1]['count'])!=int(groups['in_support'][0]['denominator_count']):
  # Locate by category; row order is not a contract.
  prop_support=next(int(x['count']) for x in groups['proposal'] if x['category']=='in_support')
  if prop_support!=int(groups['in_support'][0]['denominator_count']): raise ValueError('in_support denominator does not equal proposal-stage support count')
 return True
if __name__=='__main__':
 if len(sys.argv)!=2: raise SystemExit('usage: validate_loss_budget.py PATH.csv')
 validate(sys.argv[1]);print('PASS: two-stage integer loss-table schema, source hashes, denominators and conservation')
