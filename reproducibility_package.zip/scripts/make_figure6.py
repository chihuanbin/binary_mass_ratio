from pathlib import Path
import csv,json,hashlib,shutil
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'data/derived/loss_budget_verified.csv'
from validate_loss_budget import validate
validate(source)
with source.open(newline='') as f: rows=list(csv.DictReader(f))
prop={r['category']:int(r['count']) for r in rows if r['stage']=='proposal'}
inside={r['category']:int(r['count']) for r in rows if r['stage']=='in_support'}
Nprop=int(next(r['denominator_count'] for r in rows if r['stage']=='proposal'))
Ninside=int(next(r['denominator_count'] for r in rows if r['stage']=='in_support'))
fig,(a,b)=plt.subplots(1,2,figsize=(7.1,3.1),gridspec_kw={'width_ratios':[1.0,1.2]},constrained_layout=True)
# proposal stage: exact proportional stack, no visual minimum segment
rejected=prop['support_rejected'];accepted=prop['in_support']
a.barh([0],[rejected],color='#b24b3d',height=.44,label='Rejected by adopted MIST support')
a.barh([0],[accepted],left=[rejected],color='#487a8a',height=.44,label='In support')
a.text(rejected/2,0,f'Rejected\n{rejected:,}\n{100*rejected/Nprop:.2f}%',ha='center',va='center',color='white',fontsize=6.2,weight='bold')
a.text(rejected+accepted/2,0,f'In support\n{accepted:,}\n{100*accepted/Nprop:.2f}%',ha='center',va='center',color='white',fontsize=7,weight='bold')
a.set_xlim(0,Nprop);a.set_yticks([]);a.set_xticks([0,50000,100000,150000,200000,250000],['0','50k','100k','150k','200k','250k']);a.tick_params(axis='x',labelsize=7);a.set_xlabel('Proposal count (N=296,000)');a.set_title('A  Proposal-stage support filter',loc='left',fontsize=9)
# observation-stage direct count table; zero counts are shown as text, never inflated graphically
cats=['MIST_domain','inverse_failure','G_cut','sigma_cut','nonfinite_phot','detected']
labels=['MIST interpolation domain','Inverse failure','$G>20$ sensitivity cut','$\\sigma_{\\max}>0.1$ sensitivity cut','Nonfinite photometry','Detected']
b.set_xlim(0,1);b.set_ylim(-.75,len(cats)-.25);b.invert_yaxis();b.axis('off')
b.set_title('B  In-support first-failure accounting',loc='left',fontsize=9)
b.text(.02,-.25,f'Denominator $N_{{\\rm in\\ support}}={Ninside:,}$',transform=b.transAxes,fontsize=8,va='bottom')
for i,(c,label) in enumerate(zip(cats,labels)):
 n=inside[c]; frac=100*n/Ninside
 b.text(.02,i,label,ha='left',va='center',fontsize=7.6)
 value=f'{n:,}/{Ninside:,}' if n == 0 else f'{n:,}/{Ninside:,}  ({frac:.2f}%)'
 b.text(.98,i,value,ha='right',va='center',fontsize=7.6,family='monospace')
 b.plot([.02,.98],[i+.43,i+.43],color='#d9d9d9',lw=.45)
fig.suptitle('Proposal support and in-support first-failure counts',fontsize=10)
OUT=ROOT/'figures'
for ext in ['pdf','svg','png']:fig.savefig(OUT/f'figure6_loss_budget_verified.{ext}',dpi=600 if ext=='png' else None,bbox_inches='tight')
plt.close(fig)
shutil.copy2(source,OUT/'figure6_loss_budget_verified.csv')
manifest={'figure':'automatic manuscript Figure 4 (old Figure 6 concept)','status':'VERIFIED_EVENT_LEVEL_FIRST_FAILURE_ACCOUNTING; quota linkage unresolved','proposal_denominator':Nprop,'in_support_denominator':Ninside,'calibration_rows':200016,'in_support_minus_calibration_rows':Ninside-200016,'quota_linkage':'QUOTA_LINK_UNRESOLVED: no event IDs or retained flags tie replayed detections to the 3,704-per-state calibration quota','source':'data/derived/proposal_audit/proposal_audit.json','source_sha256':hashlib.sha256((ROOT/'data/derived/proposal_audit/proposal_audit.json').read_bytes()).hexdigest(),'support_definition':'age_M1_incompatible first-failure under adopted MIST MS/PMS interpolation support; not an unconditional physical-existence statement','loss_rule':'mutually exclusive first-failure categories; G/sigma multi-label flags separately supplied','completeness_interpretation':'G/sigma selection model is not calibrated Gaia completeness'}
(OUT/'figure6_loss_budget_verified.source.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))
