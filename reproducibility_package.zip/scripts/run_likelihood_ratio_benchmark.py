"""Frozen S3 LR benchmark; see config/lr_benchmark_plan.json."""
from pathlib import Path
import json
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; RES=ROOT/'data/derived/legacy_results'
N_SIZES=[500,1000,2000,5000,10000,20000]; AMPS=[.95,.90,.85,.80,.75,.50,.25]; WIDTHS=[1,2]
SUPPORTS=[(0,),(1,),(2,),(3,),(4,),(5,),(2,3),(0,1,2,3,4,5)]
B=2000; ALPHA=.05; SEED=20260927

def make_truth(amp,width,support):
 t=np.full((6,9),1/54); q0=3;t[np.asarray(support)[:,None],np.arange(q0,q0+width)]*=amp;t/=t.sum();return t.ravel()
def wilson(k,n):
 z=1.959963984540054;p=k/n;d=1+z*z/n;c=(p+z*z/(2*n))/d;h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d;return [float(c-h),float(c+h)]
def statistic(counts, logratio):
 # Explicit infinities are only possible when support differs; no probability floors.
 return counts@logratio

def main():
 z=np.load(RES/'calibration_200k.npz',allow_pickle=True);R=np.asarray(z['R'],float)
 assert np.all(R>=0) and np.allclose(R.sum(1),1,atol=1e-12)
 Rd=R[:,:-1];eps=Rd.sum(1)
 def project(t):
  p=Rd.T@t/(eps@t);return p/p.sum()
 pA=project(np.full(54,1/54));
 if not np.all(np.isfinite(pA)) or np.any(pA<0):raise RuntimeError('invalid null probabilities')
 rng=np.random.default_rng(SEED); thresholds={};null_rejections={}
 # Null calibration of each simple-vs-simple statistic depends on alternative pB,
 # so independently calibrate for every (N, alternative) pair using null draws.
 shape=(len(N_SIZES),len(AMPS),len(WIDTHS),len(SUPPORTS)); power=np.zeros(shape);k_alt=np.zeros(shape,dtype=int);lo=np.zeros(shape);hi=np.zeros(shape)
 for iN,N in enumerate(N_SIZES):
  for iA,amp in enumerate(AMPS):
   for iW,width in enumerate(WIDTHS):
    for iS,support in enumerate(SUPPORTS):
     pB=project(make_truth(amp,width,support))
     bothzero=(pA==0)&(pB==0); onlyA=(pA>0)&(pB==0); onlyB=(pA==0)&(pB>0)
     if np.any(onlyA):raise RuntimeError('p_B=0 where p_A>0; frozen plan requires abort')
     active=~bothzero
     lr=np.zeros_like(pA);lr[active & ~onlyB]=np.log(pB[active & ~onlyB]/pA[active & ~onlyB]);lr[onlyB]=np.inf
     dn=rng.multinomial(N,pA,size=B); tn=statistic(dn,lr);cut=float(np.quantile(tn,1-ALPHA))
     da=rng.multinomial(N,pB,size=B);ta=statistic(da,lr);k=int(np.count_nonzero(ta>cut));power[iN,iA,iW,iS]=k/B;k_alt[iN,iA,iW,iS]=k;lo[iN,iA,iW,iS],hi[iN,iA,iW,iS]=wilson(k,B)
     thresholds[f'{N}|{amp}|{width}|{support}']=cut
 np.savez_compressed(RES/'exp_lr_power_surface.npz',power=power,k_alt=k_alt,ci_low=lo,ci_high=hi,N_sizes=N_SIZES,amps=AMPS,q_widths=WIDTHS,m1_supports=np.array([','.join(map(str,s)) for s in SUPPORTS]),thresholds=thresholds,alpha=ALPHA,n_mc=B,seed=SEED)
 summary={'N_sizes':N_SIZES,'amps':AMPS,'q_widths':WIDTHS,'m1_supports':[','.join(map(str,s)) for s in SUPPORTS],'alpha':ALPHA,'n_null':B,'n_alternative':B,'seed':SEED,'thresholds':thresholds,'power':power.tolist(),'rejections':k_alt.tolist(),'wilson95_low':lo.tolist(),'wilson95_high':hi.tolist(),'zero_floor_used':False,'statistic':'T=sum_j n_j log(p_B[j]/p_A[j])','threshold_calibration':'independent null draws per N and fixed alternative'}
 (RES/'exp_lr_power_surface.json').write_text(json.dumps(summary,indent=2));print(f'completed {power.size} cells; range={power.min():.3f}..{power.max():.3f}; output={RES}/exp_lr_power_surface.json')
if __name__=='__main__':main()
