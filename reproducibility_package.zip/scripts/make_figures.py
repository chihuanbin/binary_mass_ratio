from pathlib import Path
import json, hashlib, csv
import numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'data/derived/legacy_results'; OUT=ROOT/'figures'; OUT.mkdir(exist_ok=True)

def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
# Figure 3: canonical joint response, with detected and missing-state column labelled.
z=np.load(RES/'calibration_200k.npz',allow_pickle=True); R=np.asarray(z['R'],float)
fig,ax=plt.subplots(figsize=(7.0,5.4),constrained_layout=True)
im=ax.imshow(R,origin='lower',aspect='auto',interpolation='nearest',cmap='viridis',vmin=0,vmax=max(float(R[:,:54].max()),1e-6))
for k in range(1,6): ax.axhline(k*9-.5,color='white',lw=.55,alpha=.85); ax.axvline(k*9-.5,color='white',lw=.55,alpha=.85)
ax.axvline(53.5,color='crimson',lw=1.2)
ax.set(xlim=(-.5,54.5),ylim=(-.5,53.5),xlabel='Recovered state (six $M_1$ bins × nine $q$ bins; final column = NOT_OBSERVED)',ylabel='True state (six $M_1$ bins × nine $q$ bins)')
ax.set_xticks([4,13,22,31,40,49,54],['$1$–$1.5$','$1.5$–$2$','$2$–$2.5$','$2.5$–$3$','$3$–$4$','$4$–$5$','NOT\nOBS'])
ax.set_yticks([4,13,22,31,40,49],['$1$–$1.5$','$1.5$–$2$','$2$–$2.5$','$2.5$–$3$','$3$–$4$','$4$–$5$'])
ax.tick_params(axis='both',labelsize=8)
cb=fig.colorbar(im,ax=ax,pad=.02);cb.set_label('Response probability per true-state row')
ax.set_title('Restricted joint response; 54 × 55; NOT_OBSERVED probability is zero',loc='left',fontsize=10)
for ext in ['pdf','svg','png']: fig.savefig(OUT/f'figure3_joint_response.{ext}',dpi=600 if ext=='png' else None)
plt.close(fig)
np.savetxt(OUT/'figure3_joint_response.csv',R,delimiter=',',fmt='%.12g')
manifest={'figure':'Figure 3 candidate','status':'SOURCE_VERIFIED_FOR_ARCHIVED_OPERATOR','operator_id':'restricted_joint_54x55','array_shape':list(R.shape),'training_rows':int(z['n_total']),'rows_per_true_state':[int(x) for x in z['n_per_state']],'efficiency_min':float(R[:,:-1].sum(1).min()),'efficiency_max':float(R[:,:-1].sum(1).max()),'selection_interpretation':'conditional training response; not calibrated Gaia completeness','source_file':'calibration_200k.npz','source_sha256':digest(RES/'calibration_200k.npz')}
(OUT/'figure3_joint_response.source.json').write_text(json.dumps(manifest,indent=2))
# Figure 2: test-dependent sampled power grids; no smoothing.
z=np.load(RES/'exp34_power_surface.npz',allow_pickle=True)
lr=np.load(RES/'exp_lr_power_surface.npz',allow_pickle=True)
N_FOCUS=20_000; Q_START=0.4; NREP=2_000; WIDTH_INDEX=0
N_INDEX=int(np.flatnonzero(z['N_sizes']==N_FOCUS)[0])
if not np.array_equal(z['amps'],lr['amps']) or not np.array_equal(z['m1_supports'],lr['m1_supports']):
 raise ValueError('Pearson/LR grid coordinates differ')
if int(z['q_widths'][WIDTH_INDEX]) != int(lr['q_widths'][WIDTH_INDEX]):
 raise ValueError('Pearson/LR q-width grid differs')
P=z['P_det'][N_INDEX,:,WIDTH_INDEX,:]; L=lr['power'][N_INDEX,:,WIDTH_INDEX,:]; amps=z['amps'].astype(float)
support_idx=[str(x) for x in z['m1_supports']]
mass_labels={'0':'$1.0$–$1.5$', '1':'$1.5$–$2.0$', '2':'$2.0$–$2.5$', '3':'$2.5$–$3.0$', '4':'$3.0$–$4.0$', '5':'$4.0$–$5.0$', '2,3':'$2.0$–$3.0$', '0,1,2,3,4,5':'All six bins'}
supports=[mass_labels.get(s,s) for s in support_idx]
# Each displayed cell is resolved through its full experiment key before plotting.
focus_key=(N_FOCUS,Q_START,Q_START+0.1,0.1,0.75,'3')
rows=[]
for test,data,source in [('Pearson',P,z),('LR',L,lr)]:
 for ia,wgt in enumerate(amps):
  for ic,support in enumerate(support_idx):
   width=float(source['q_widths'][WIDTH_INDEX])*0.1
   key=(N_FOCUS,Q_START,Q_START+width,width,float(wgt),support)
   count_float=float(data[ia,ic])*NREP
   count=int(round(count_float))
   if not np.isclose(count_float,count,atol=1e-7):
    raise ValueError(f'Non-integer Monte Carlo count for {test} {key}: {count_float}')
   if test=='Pearson':
    threshold=float(source['thresh'].item()[str(N_FOCUS)])
    threshold_branch='per-N shared-null Pearson threshold'
    source_row=f'{N_INDEX},{ia},{WIDTH_INDEX},{ic}'
   else:
    # Stored keys use Python tuple formatting, including a trailing comma for single bins.
    support_tuple=tuple(int(x) for x in support.split(','))
    thrkey=f'{N_FOCUS}|{wgt}|{int(source["q_widths"][WIDTH_INDEX])}|{support_tuple}'
    threshold=float(source['thresholds'].item()[thrkey])
    threshold_branch='alternative-specific LR null threshold'
    source_row=f'{N_INDEX},{ia},{WIDTH_INDEX},{ic}'
   rows.append({'test':test,'key':key,'source_row':source_row,'display_row':ia,'display_column':ic,
                'count':count,'Nrep':NREP,'power':count/NREP,'threshold':threshold,
                'threshold_branch':threshold_branch,'annotation':key==focus_key})
for test in ('Pearson','LR'):
 focus=[r for r in rows if r['test']==test and r['annotation']]
 if len(focus)!=1: raise ValueError(f'Expected exactly one {test} focus cell, found {len(focus)}')
 if amps[focus[0]['display_row']] != 0.75 or focus[0]['key'][5] != '3':
  raise ValueError(f'{test} focus key does not map to w=0.75, M1 support index 3')
fig,axs=plt.subplots(1,2,figsize=(7.1,3.55),sharey=True,constrained_layout=True)
for ax,data,title in zip(axs,[P,L],['Pearson distance','Simple-vs-simple likelihood ratio']):
 im=ax.imshow(data,origin='lower',aspect='auto',interpolation='nearest',cmap='magma',vmin=0,vmax=1)
 ax.set_xticks(range(len(supports)),supports,rotation=35,ha='right',fontsize=7)
 ax.set_yticks(range(len(amps)),[f'{v:.2f}' for v in amps],fontsize=7)
 ax.set_xlabel(r'Primary-mass support ($M_\odot$)');ax.set_title(title,fontsize=9)
axs[0].set_ylabel('Relative dip weight $w$ (sampled levels)')
# Derive annotation coordinates and values from the same unique tidy records.
for ax,test in zip(axs,['Pearson','LR']):
 r=next(x for x in rows if x['test']==test and x['annotation'])
 ax.text(r['display_column'],r['display_row'],f"{r['count']}/{r['Nrep']}\n{r['power']:.4f}",ha='center',va='center',fontsize=6.5,color='white',weight='bold')
fig.suptitle('Test-dependent power on the sampled grid ($N=20{,}000$; one $q$ bin)',fontsize=10)
cb=fig.colorbar(im,ax=axs,pad=.025,shrink=.9);cb.set_label('Estimated rejection fraction')
for ext in ['pdf','svg','png']:fig.savefig(OUT/f'figure5_power_grid.{ext}',dpi=600 if ext=='png' else None)
plt.close(fig)
def wilson(k,n=2000):
 zc=1.959963984540054;p=k/n;d=1+zc*zc/n;c=(p+zc*zc/(2*n))/d;h=zc*np.sqrt(p*(1-p)/n+zc*zc/(4*n*n))/d;return c-h,c+h
with (OUT/'figure5_power_grid.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['relative_dip_weight','m1_support_indices','m1_support_label','pearson_rejections','pearson_power','pearson_wilson95_low','pearson_wilson95_high','lr_rejections','lr_power','lr_wilson95_low','lr_wilson95_high','N','q_width_bins','alpha','null_replicates','alternative_replicates'])
 for ia,a in enumerate(amps):
  for isup,sup in enumerate(support_idx):
   kp=int(round(P[ia,isup]*2000));kl=int(lr['k_alt'][-1,ia,0,isup]);pl,ph=wilson(kp);ll,lh=wilson(kl)
   w.writerow([a,sup,supports[isup],kp,kp/2000,pl,ph,kl,kl/2000,ll,lh,20000,1,.05,2000,2000])
with (OUT/'figure2_cell_map.csv').open('w',newline='') as f:
 fields=['test','N','q_lo','q_hi','q_width','relative_weight','m1_support_indices','m1_support_label','source_row','display_row','display_column','rejections','Nrep','power','threshold','threshold_branch','annotation']
 writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
 for r in rows:
  N,qlo,qhi,qwidth,wgt,support=r['key']
  writer.writerow({'test':r['test'],'N':N,'q_lo':qlo,'q_hi':qhi,'q_width':qwidth,'relative_weight':wgt,
   'm1_support_indices':support,'m1_support_label':supports[r['display_column']],'source_row':r['source_row'],'display_row':r['display_row'],'display_column':r['display_column'],
   'rejections':r['count'],'Nrep':r['Nrep'],'power':r['power'],'threshold':r['threshold'],
   'threshold_branch':r['threshold_branch'],'annotation':str(r['annotation']).lower()})
manifest={'figure':'automatic manuscript Figure 2 (old Figure 5)','status':'SOURCE_VERIFIED_FOR_TESTED_GRID','focus_annotation':'computed from unique full-key record; displayed coordinates derived from source grid order','cell_map':'figures/figure2_cell_map.csv','cell_map_sha256':digest(OUT/'figure2_cell_map.csv'),'generator':'scripts/make_figures.py','generator_sha256':digest(Path(__file__)),'tests':['Pearson distance from flat-population detected-state probability','simple-vs-simple likelihood ratio T=sum n_j log(p_B[j]/p_A[j])'],'alpha':.05,'null_replicates_per_N_and_alternative':2000,'alternative_replicates_per_cell':2000,'N':N_FOCUS,'q_interval':[Q_START,Q_START+0.1],'q_width':.1,'m1_interval_Msun':[2.5,3.0],'relative_weight':.75,'normalization':'global after relative cell downweighting','focus_rejections':[205,1363],'focus_power':[.1025,.6815],'same_focus_alternative_and_response':True,'response_npz_sha256':digest(RES/'calibration_200k.npz'),'source_files':['exp34_power_surface.npz','exp_lr_power_surface.npz'],'source_sha256':[digest(RES/'exp34_power_surface.npz'),digest(RES/'exp_lr_power_surface.npz')],'limits':'discrete sampled alternatives only; LR uses the specific alternative as a fixed simple hypothesis; no composite-optimality or universal impossibility claim'}
(OUT/'figure5_power_grid.source.json').write_text(json.dumps(manifest,indent=2))
