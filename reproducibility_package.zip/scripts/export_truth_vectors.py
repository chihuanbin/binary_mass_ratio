from pathlib import Path
import csv,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
edges_m=np.array([1,1.5,2,2.5,3,4,5.],float); edges_q=np.linspace(.1,1.,10)
centres=(edges_q[:-1]+edges_q[1:])/2
s0=np.full((6,9),1/54)
s1=s0.copy(); s1[3,3:5]*=.75; s1/=s1.sum()
out=ROOT/'data/derived/reconstruction_truth_54state.csv'
with out.open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['state_index','M1_bin','M1_lo_Msun','M1_hi_Msun','q_bin','q_lo','q_hi','q_center','t_S0','t_S1'])
 for m in range(6):
  for q in range(9):w.writerow([m*9+q,m,edges_m[m],edges_m[m+1],q,edges_q[q],edges_q[q+1],centres[q],s0[m,q],s1[m,q]])
summary=[]
for name,t in [('S0',s0),('S1',s1)]:
 for m in range(6):
  wm=t[m].sum(); qmean=float(t[m]@centres/wm)
  summary.append({'population':name,'M1_bin':m,'M1_lo_Msun':float(edges_m[m]),'M1_hi_Msun':float(edges_m[m+1]),'M1_weight':float(wm),'mean_q_bin_center':qmean,'mean_q_continuous_uniform_within_bins':qmean})
 total=float((t*centres[None,:]).sum())
 (ROOT/'data/derived'/f'{name.lower()}_mass_bin_means.json').write_text(json.dumps([x for x in summary if x['population']==name],indent=2)+'\n')
(ROOT/'data/derived/reconstruction_population_truth_summary.json').write_text(json.dumps({'overall_q_mean_q_bin_center':{'S0':float((s0*centres[None,:]).sum()),'S1':float((s1*centres[None,:]).sum())},'mass_bin_conditional_means':summary,'within_bin_assumption':'The experiment draws q uniformly within each q interval; therefore the design-expected continuous q mean equals the q-bin-center weighted mean. This equality is design-based, not an inference from a plotted curve.','definitions':'S0 uniform on 54 states; S1 has states (M1 index 3, q indices 3 and 4) multiplied by relative weight 0.75, followed by global normalization.'},indent=2)+'\n')
print((ROOT/'data/derived/reconstruction_population_truth_summary.json').read_text())
