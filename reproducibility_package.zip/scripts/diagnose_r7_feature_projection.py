"""Deterministic projections of two archived population contrasts through frozen R.

This is an added deterministic diagnostic, not a Monte Carlo experiment.
All products go to a required, caller-selected output directory.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RFILE = ROOT / "data/derived/legacy_results/calibration_200k.npz"
TRUTH = ROOT / "data/derived/reconstruction_truth_54state.csv"
M1_EDGES = np.array([1, 1.5, 2, 2.5, 3, 4, 5.], dtype=float)
Q_EDGES = np.linspace(.1, 1., 10)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path,
                        help="new directory for CSV, JSON and vector PDF")
    parser.add_argument("--overwrite", action="store_true",
                        help="replace only this script's three named products in the output directory")
    args = parser.parse_args()
    outdir = args.output_dir.expanduser().resolve()
    names = ["feature_projection_r7.csv", "feature_projection_r7.json",
             "feature_projection_r7.pdf"]
    if outdir.exists() and any((outdir / n).exists() for n in names) and not args.overwrite:
        raise SystemExit(f"Refusing to overwrite existing diagnostic products in {outdir}")
    outdir.mkdir(parents=True, exist_ok=True)

    with np.load(RFILE, allow_pickle=True) as z:
        R = np.asarray(z["R"], dtype=np.float64)
        m1_edges = np.asarray(z["m1_edges"], dtype=float)
        q_edges = np.asarray(z["q_edges"], dtype=float)
    if R.shape != (54, 55) or not np.array_equal(m1_edges, M1_EDGES) or not np.allclose(q_edges, Q_EDGES, rtol=0, atol=1e-14):
        raise ValueError("Frozen response dimensions/state edges do not match the declared state ordering")
    Rdet = R[:, :54]
    eps = Rdet.sum(axis=1)
    if not np.all(np.isfinite(R)) or np.any(R < 0) or not np.allclose(R.sum(axis=1), 1, rtol=0, atol=1e-12):
        raise ValueError("Response contains invalid probabilities or non-unit full rows")
    if not np.allclose(eps, 1, rtol=0, atol=1e-12):
        raise ValueError("This linear projection check requires unit detection efficiency")

    rows = list(csv.DictReader(TRUTH.open(newline="")))
    if len(rows) != 54 or [int(r["state_index"]) for r in rows] != list(range(54)):
        raise ValueError("Truth table must contain ordered state_index 0..53")
    for row in rows:
        m, q = int(row["M1_bin"]), int(row["q_bin"])
        if (float(row["M1_lo_Msun"]) != M1_EDGES[m] or
                float(row["M1_hi_Msun"]) != M1_EDGES[m+1] or
                abs(float(row["q_lo"]) - Q_EDGES[q]) > 1e-14 or
                abs(float(row["q_hi"]) - Q_EDGES[q+1]) > 1e-14):
            raise ValueError("Truth-table labels do not match frozen row-major state ordering")
    t_s0 = np.array([float(r["t_S0"]) for r in rows])
    t_s1 = np.array([float(r["t_S1"]) for r in rows])
    t_uniform = np.full(54, 1/54, dtype=float)
    t_lr = t_uniform.copy().reshape(6, 9)
    t_lr[3, 3] *= .75
    t_lr = (t_lr / t_lr.sum()).ravel()
    expected_s1 = t_uniform.copy().reshape(6, 9)
    expected_s1[3, 3:5] *= .75
    expected_s1 = (expected_s1 / expected_s1.sum()).ravel()
    if not np.array_equal(t_s0, t_uniform) or not np.array_equal(t_s1, expected_s1):
        raise ValueError("Archived S0/S1 truth vectors disagree with their documented definitions")

    comparisons = [("S3-LR-01", t_uniform, t_lr), ("Experiment 5", t_s0, t_s1)]
    record_rows: list[dict[str, object]] = []
    summary = []
    vmax = 0.0
    for exp_id, t_a, t_b in comparisons:
        if not np.isclose(t_a.sum(), 1, atol=1e-13) or not np.isclose(t_b.sum(), 1, atol=1e-13):
            raise ValueError(f"{exp_id}: latent vectors do not normalize")
        p_a = Rdet.T @ t_a / (eps @ t_a)
        p_b = Rdet.T @ t_b / (eps @ t_b)
        dt, dp = t_b - t_a, p_b - p_a
        if not (np.isclose(p_a.sum(), 1, atol=1e-12) and np.isclose(p_b.sum(), 1, atol=1e-12)):
            raise ValueError(f"{exp_id}: detected probabilities do not normalize")
        if not (abs(dt.sum()) <= 1e-12 and abs(dp.sum()) <= 1e-12):
            raise ValueError(f"{exp_id}: contrast does not sum to zero")
        if not np.allclose(dp, Rdet.T @ dt, rtol=0, atol=1e-12):
            raise ValueError(f"{exp_id}: unit-efficiency linear mapping identity failed")
        vmax = max(vmax, float(np.max(np.abs(dt))), float(np.max(np.abs(dp))))
        summary.append({"source_experiment_id": exp_id, "comparison_label": "S0 to LR-focus alternative" if exp_id == "S3-LR-01" else "S0 to S1",
                        "sum_delta_t": float(dt.sum()),
                        "sum_delta_p": float(dp.sum()), "max_abs_delta_t": float(np.max(np.abs(dt))),
                        "max_abs_delta_p": float(np.max(np.abs(dp))),
                        "probability_identity_max_abs_residual": float(np.max(np.abs(dp-Rdet.T@dt)))})
        for role, vec_a, vec_b, delta in (("latent_true", t_a, t_b, dt), ("detected_recovered", p_a, p_b, dp)):
            for idx, value in enumerate(delta):
                mi, qi = divmod(idx, 9)
                record_rows.append({"experiment_id": exp_id, "state_role": role,
                    "state_index": idx, "M1_bin": mi, "M1_lo_Msun": M1_EDGES[mi],
                    "M1_hi_Msun": M1_EDGES[mi+1], "q_bin": qi,
                    "q_lo": Q_EDGES[qi], "q_hi": Q_EDGES[qi+1],
                    "t_or_p_A": float(vec_a[idx]), "t_or_p_B": float(vec_b[idx]),
                    "delta_t_or_p": float(value)})

    with (outdir / names[0]).open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(record_rows[0]))
        w.writeheader(); w.writerows(record_rows)
    manifest = {"status": "ADDED_DETERMINISTIC_DIAGNOSTIC", "experiment_scope": "two archived contrasts only; no Monte Carlo",
        "generator": "scripts/diagnose_r7_feature_projection.py", "generator_sha256": sha(Path(__file__).resolve()),
        "R_file": "data/derived/legacy_results/calibration_200k.npz", "R_file_sha256": sha(RFILE),
        "R_array_sha256_little_endian_float64": hashlib.sha256(np.asarray(R, dtype="<f8").tobytes()).hexdigest(),
        "truth_file": "data/derived/reconstruction_truth_54state.csv", "truth_file_sha256": sha(TRUTH),
        "orientation": "R[true_state, detected_state]; final column is NOT_OBSERVED; detected columns follow row-major M1-bin then q-bin state order",
        "probability_definition": "p(t)=R_detected.T @ t / sum_i(t_i * epsilon_i)",
        "unit_efficiency": True, "identity_checked": "delta_p = R_detected.T @ delta_t",
        "numeric_tolerance": 1e-12, "comparisons": summary,
        "definitions": {"S3-LR-01": "uniform S0 to one q-bin relative-weight-0.75 alternative in M1=[2.5,3) Msun, q=[0.4,0.5), globally normalized; ID from config/lr_benchmark_plan.json", "Experiment 5": "archived uniform S0 to distinct two-adjacent-q-bin S1, each relative weight 0.75 in M1=[2.5,3) Msun, globally normalized; source module identifies Experiment 5 and outputs S0/S1 but stores no separate machine-readable experiment_id"},
        "interpretation_limit": "maps only these specified latent probability contrasts through the frozen response; not a general information-loss fraction, identifiability direction, physical mechanism, or new detection boundary"}
    (outdir / names[1]).write_text(json.dumps(manifest, indent=2) + "\n")

    fig, axes = plt.subplots(2, 2, figsize=(7.1, 5.1), constrained_layout=True)
    labels = [("S3-LR-01", "latent $\\Delta t$", 0), ("S3-LR-01", "detected $\\Delta p$", 1),
              ("Experiment 5", "latent $\\Delta t$", 0), ("Experiment 5", "detected $\\Delta p$", 1)]
    vmax = max(vmax, 1e-12)
    image = None
    for ax, (exp_id, title, idx) in zip(axes.flat, labels):
        sel = [r for r in record_rows if r["experiment_id"] == exp_id and r["state_role"] == ("latent_true" if idx == 0 else "detected_recovered")]
        matrix = np.array([r["delta_t_or_p"] for r in sel]).reshape(6, 9)
        image = ax.imshow(matrix, origin="lower", aspect="auto", cmap="coolwarm", vmin=-vmax, vmax=vmax,
                          extent=(Q_EDGES[0], Q_EDGES[-1], M1_EDGES[0], M1_EDGES[-1]), interpolation="nearest")
        ax.set_xticks(Q_EDGES); ax.tick_params(axis="x", labelrotation=45, labelsize=7)
        ax.set_yticks(M1_EDGES); ax.tick_params(axis="y", labelsize=7)
        ax.set_xlabel("Mass ratio $q$"); ax.set_ylabel(r"Primary mass $M_1\ (M_\odot)$")
        ax.set_title(f"{exp_id} ({title})", fontsize=8)
    fig.colorbar(image, ax=axes, label="Probability change", shrink=.85)
    fig.savefig(outdir / names[2], bbox_inches="tight")
    plt.close(fig)
    manifest["outputs"] = {name: sha(outdir / name) for name in (names[0], names[2])}
    (outdir / names[1]).write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"output_dir": str(outdir), "files": names, "status": manifest["status"],
                      "comparisons": summary}, indent=2))


if __name__ == "__main__":
    main()
