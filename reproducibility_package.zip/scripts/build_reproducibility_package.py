"""Build the curated R7 PASP review supplement; never recursively include ZIPs."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]
ZIP=ROOT/'submission/reproducibility_package.zip'
MANIFEST=ROOT/'provenance/r7_story_package_manifest.json'

FILES=[
'README.md','docs/USING_BENCHMARK.md',
'manuscript/main.tex','manuscript/main.pdf','manuscript/references.bib',
'manuscript/aastex701.cls','manuscript/aasjournalv7.bst',
'submission/AUTHOR_METADATA_QUERY.txt',
'config/lr_benchmark_plan.json','config/proposal_audit_plan.json',
'provenance/output_inventory.csv','provenance/operator_registry.csv',
'provenance/sampling_provenance.md','provenance/joint_bootstrap_specification.json',
'provenance/r6_source_ledger.csv',
'provenance/recovered_sources/proposal_audit_script.py',
'provenance/recovered_sources/proposal_audit_script.meta.json',
'data/derived/legacy_results/calibration_200k.npz',
'data/derived/legacy_results/calibration_summary.json',
'data/derived/legacy_results/exp34_power_surface.npz',
'data/derived/legacy_results/exp34_power_surface.json',
'data/derived/legacy_results/exp_lr_power_surface.npz',
'data/derived/legacy_results/exp_lr_power_surface.json',
'data/derived/legacy_results/exp5_operator_uncertainty.json',
'data/derived/proposal_audit/proposal_audit.json',
'data/derived/proposal_audit/calibration_summary.json',
'data/derived/loss_budget_verified.csv','data/derived/multi_label_cut_flags.csv',
'data/derived/lr_null_validation.json','data/derived/r4_evidence_recomputation.json',
'data/derived/reconstruction_seed_results.csv','data/derived/reconstruction_summary.csv',
'data/derived/reconstruction_truth_54state.csv',
'data/derived/reconstruction_population_truth_summary.json',
'data/derived/s0_mass_bin_means.json','data/derived/s1_mass_bin_means.json',
'data/derived/reconstruction_results.source.json',
'data/derived/r7_feature_projection/feature_projection_r7.csv',
'data/derived/r7_feature_projection/feature_projection_r7.json',
'data/derived/r7_feature_projection/feature_projection_r7.pdf',
'figures/figure2_cell_map.csv',
'figures/figure3_joint_response.csv','figures/figure3_joint_response.pdf',
'figures/figure3_joint_response.svg','figures/figure3_joint_response.source.json',
'figures/figure5_power_grid.csv','figures/figure5_power_grid.pdf',
'figures/figure5_power_grid.svg','figures/figure5_power_grid.source.json',
'figures/figure6_loss_budget_verified.csv','figures/figure6_loss_budget_verified.pdf',
'figures/figure6_loss_budget_verified.svg','figures/figure6_loss_budget_verified.source.json',
'figures/reconstruction_all_seeds.pdf','figures/reconstruction_all_seeds.svg',
'scripts/diagnose_r7_feature_projection.py',
'src/legacy_scripts/forward_model.py','src/legacy_scripts/unfolding.py',
'src/legacy_scripts/cluster_catalogue.py','src/legacy_scripts/mist_loader.py',
'src/legacy_scripts/exp5_operator_uncertainty.py',
'scripts/audit_r6_delivery.py','scripts/build_reproducibility_package.py',
'scripts/run_likelihood_ratio_benchmark.py',
'scripts/check_r4_figure_mapping.py','scripts/export_reconstruction_results.py',
'scripts/export_truth_vectors.py','scripts/make_figure6.py','scripts/make_figures.py',
'scripts/r4_evidence_recompute.py','scripts/run_calibration_event_audit.py',
'scripts/run_focused_null_validation.py','scripts/run_likelihood_ratio_benchmark.py',
'scripts/validate_loss_budget.py',
'reports/R7_CLAIM_EVIDENCE_SCOPE.csv','reports/STORY_SCIENCE_CHANGELOG.md',
'reports/R7_FINAL_STATUS.md','reports/R7_execution.log','reports/R7_latexmk.log',
'reports/R7_reconstruction_export.log','reports/R7_projection_diagnostic.log',
'reports/R7_visual_review.md','reports/R4_REFERENCE_AUDIT.md',
'reports/R2_closure_test.log','reports/R2_loss_budget_check.log',
'reports/R4_evidence_recomputation.log','reports/R4_reconstruction_export.log',
'reports/R4_figure_mapping_check.log','reports/R6_latexmk.log',
'reports/R6_delivery_difference.md','reports/R6_delivery_audit.log',

]
paths=[]
for rel in FILES:
    p=ROOT/rel
    if not p.is_file():
        raise FileNotFoundError(rel)
    paths.append(p)
if any(p.suffix.lower()=='.zip' for p in paths):
    raise RuntimeError('Nested ZIP files are forbidden in the release archive')
paths=sorted(set(paths))
manifest={
 'release':'PASP R7 story/science review supplement',
 'derived_artifact_reproduction':'PREVIOUSLY_ACCEPTED; R7 reconstruction reference-line figure and deterministic projection diagnostic regenerated from archived arrays',
 'conditional_experiment_reproduction':'NOT_CLAIMED; legacy exp5 script retains src/results layout dependency; no portable full replay runner',
 'raw_to_response_reproduction':'NOT_RUN; MIST/catalogue raw inputs are not packaged or rerun',
 'proposal_audit':'COUNT_SUMMARY_ONLY; no event-level recertification or event-to-quota linkage',
 'likelihood_ratio_grid':'Current figure has 56 LR cells; full 672-cell bitwise reproduction is not claimed; three known two-q-bin mismatches remain documented',
 'new_scientific_monte_carlo':'NONE',
 'deterministic_projection':'ADDED_DETERMINISTIC_DIAGNOSTIC; two specified contrasts only; unit-efficiency identity checked',
 'author_metadata':'AWAITING_AUTHOR',
 'public_release':False,
 'submission_or_doi':False,
 'nested_archives_included':False,
 'payload_file_count':len(paths),
 'files':[{'path':p.relative_to(ROOT).as_posix(),'size':p.stat().st_size,
           'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
}
MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in paths: z.write(p,p.relative_to(ROOT).as_posix())
    z.write(MANIFEST,MANIFEST.relative_to(ROOT).as_posix())
print(json.dumps({'zip':str(ZIP),'manifest':str(MANIFEST),
 'payload_files':len(paths),'archive_members':len(paths)+1,'bytes':ZIP.stat().st_size,
 'sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest()},indent=2))
