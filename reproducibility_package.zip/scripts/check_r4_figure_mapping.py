"""Check that Figure 2's focused source values map to the annotated cells."""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "figures" / "figure2_cell_map.csv"
rows = list(csv.DictReader(path.open()))
if len(rows) != 112:
    raise ValueError(f"Expected 112 plotted cells, found {len(rows)}")
for test in ("Pearson", "LR"):
    subset = [r for r in rows if r["test"] == test]
    if len(subset) != 56:
        raise ValueError(f"{test}: expected 56 grid cells, got {len(subset)}")
    keys = {(r["N"], r["q_lo"], r["q_hi"], r["q_width"], r["relative_weight"], r["m1_support_indices"]) for r in subset}
    if len(keys) != 56:
        raise ValueError(f"{test}: duplicated or missing full experiment keys")
    focus = [r for r in subset if r["annotation"] == "true"]
    if len(focus) != 1:
        raise ValueError(f"{test}: expected one annotated focus cell")
    f = focus[0]
    if (float(f["N"]), float(f["q_lo"]), float(f["q_hi"]), float(f["q_width"]),
            float(f["relative_weight"]), f["m1_support_indices"]) != (20000.0, 0.4, 0.5, 0.1, 0.75, "3"):
        raise ValueError(f"{test}: wrong scientific focus key: {f}")
    if (int(f["display_row"]), int(f["display_column"])) != (4, 3):
        raise ValueError(f"{test}: focus key maps to incorrect display coordinates")
    with np.load(ROOT / "data" / "derived" / "legacy_results" /
                 ("exp34_power_surface.npz" if test == "Pearson" else "exp_lr_power_surface.npz"),
                 allow_pickle=True) as z:
        if test == "Pearson":
            ia = int(np.flatnonzero(z["amps"] == 0.75)[0])
            ic = int(np.flatnonzero(z["m1_supports"] == "3")[0])
            count = round(float(z["P_det"][-1, ia, 0, ic]) * 2000)
        else:
            ia = int(np.flatnonzero(z["amps"] == 0.75)[0])
            ic = int(np.flatnonzero(z["m1_supports"] == "3")[0])
            count = int(z["k_alt"][-1, ia, 0, ic])
    if count != int(f["rejections"]):
        raise ValueError(f"{test}: tidy table count differs from source array")
    print(f"{test}: {count}/2000 at q=[0.4,0.5), w=0.75, M1 support 3; display row=4, column=3")
print(f"PASS: {len(rows)}/112 Figure 2 keys and source-value coordinates checked")
