# Using the PASP CMD mass-ratio benchmark

This supplement contains a frozen, support-conditioned response and derived
validation products for one discretized CMD-to-\((M_1,q)\) workflow. It is
intended for reproducing the included tables/figures and for planning a
matched validation of another response. It is not a ready-made response for a
different cluster.

## Reproduce the included derived products

The recorded environment for the previous accepted derived-artifact run was
Python 3.13.5, NumPy 2.1.3, SciPy 1.15.3, and Matplotlib 3.10.0, using
`/opt/anaconda3/bin/python`. Commands are run from the package root. The
following commands regenerate truth/reconstruction summaries and figures from
the archived derived arrays; commands writing into `data/derived/` or
`figures/` replace those derived products, so retain a copy when comparing
versions.

```sh
/opt/anaconda3/bin/python scripts/export_truth_vectors.py
MPLCONFIGDIR=/private/tmp/mpl_pasp MPLBACKEND=Agg /opt/anaconda3/bin/python scripts/export_reconstruction_results.py
/opt/anaconda3/bin/python scripts/r4_evidence_recompute.py
MPLCONFIGDIR=/private/tmp/mpl_pasp MPLBACKEND=Agg /opt/anaconda3/bin/python scripts/make_figures.py
MPLCONFIGDIR=/private/tmp/mpl_pasp MPLBACKEND=Agg /opt/anaconda3/bin/python scripts/make_figure6.py
```

These are derived-artifact regeneration commands. They do not rerun the
20-realization inverse fits or the 1,000 internal bootstrap fits per
realization. The current LR figure uses 56 archived LR cells; the full
672-cell historical grid is not claimed to be bitwise reproduced. The three
known double-q-bin count discrepancies remain documented and outside the
current displayed grid. Do not interpret `669/672` as a full-grid pass.

The archived focused null result is 482/10,000 Pearson rejections and
563/10,000 LR rejections. Its original command was
`/opt/anaconda3/bin/python scripts/run_focused_null_validation.py`; it is a
Monte Carlo command that writes the retained null-result JSON, so it is not
part of a routine plot-only regeneration. The result checks one focused
comparison only. It does not validate null size across the full surface.

## Deterministic projection smoke/use command

The small deterministic projection entry point reads the frozen matrix and
archived S0/S1 truth vectors, checks state ordering and probability
normalization, and writes new products to a required output directory. It
does not simulate data or modify archived results:

```sh
MPLCONFIGDIR=/private/tmp/mpl_pasp MPLBACKEND=Agg \
  /opt/anaconda3/bin/python scripts/diagnose_r7_feature_projection.py \
  --output-dir /private/tmp/pasp_projection_example
```

The run produces a tidy per-state CSV, a JSON source/identity record, and a
vector PDF. It evaluates only (1) S3-LR-01, uniform S0 to the one-q-bin LR
focus alternative, and (2) Experiment 5's distinct reconstruction S0-to-S1
two-q-bin contrast. The Experiment 5 source stores S0/S1 labels but no
separate machine-readable experiment ID; the output records that limitation
instead of inventing a historical ID.
For this archived unit-efficiency response,
`p(t) = R_detected.T @ t / sum_i(t_i * epsilon_i)` and
`delta_p = R_detected.T @ delta_t`. The two comparisons are not consecutive
stages of one experiment and do not define a general information-loss score.

## What is and is not reproduced

| Level | Meaning | Current package status |
|---|---|---|
| Figure/table regeneration | Rebuild derived summaries and plots from archived arrays | Previously accepted; the R7 reconstruction figure and projection diagnostic were regenerated |
| Summary recomputation | Recalculate available statistics from archived result arrays | Previously accepted; missing per-state errors and interval endpoints remain unavailable |
| Frozen-operator conditional experiment | Rerun specified simulations/inference using frozen `R` | No portable full runner is claimed. The legacy `src/legacy_scripts/exp5_operator_uncertainty.py` expects `src/results/calibration_200k.npz` and writes to `src/results/`; it is not a package-root command |
| Raw-input-to-response | Recreate `R` from MIST and catalogue inputs | `NOT_RUN`; raw MIST and full catalogue inputs are not packaged or processed here |

The proposal replay has count-summary agreement, but this package does not
recertify it event by event or link its detected proposals to the 200,016
calibration quota rows. `45,598` is only the difference between two counts;
it is not assigned to a quota-surplus or observation-loss category.

## Adapting the workflow

For a new cluster or inference method, prepare a new membership definition,
cluster-specific age/metallicity/distance/extinction distributions, photometric
uncertainty and selection/completeness model, within-bin population draws,
and a response calibration consistent with the intended estimand. Then run
repeated-sampling checks for test sensitivity, aggregate and local
reconstruction relative to an explicit baseline, and interval coverage with
the independent replication unit defined in advance. The present package
does not implement an adapter that accepts an arbitrary cluster catalogue or
automatically performs those steps. Do not apply the frozen matrix or its
power/coverage values as a performance guarantee for another target.
