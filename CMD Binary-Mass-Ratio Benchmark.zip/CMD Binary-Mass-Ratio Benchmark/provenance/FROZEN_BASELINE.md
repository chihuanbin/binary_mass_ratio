# Frozen baseline and release rules

The archived matrix and derived results are fixed inputs to this release. The
release framework may validate or project them, but it must not replace them
with newly simulated values.

## Operator identity

- Array: `data/derived/legacy_results/calibration_200k.npz`, key `R`.
- Orientation: 54 rows are true `(M1, q)` states; 54 detected outcome columns
  are followed by `NOT_OBSERVED`.
- Primary-mass edges: 1, 1.5, 2, 2.5, 3, 4, and 5 solar masses.
- Mass-ratio edges: 0.1 through 1.0 in steps of 0.1.
- Calibration: 3,704 retained rows per true state, 200,016 total.
- The matrix is conditional on support and detected retained calibration
  records. Its `NOT_OBSERVED` entries are zero; this does not estimate a
  general Gaia completeness function.
- A separate proposal replay records 296,000 proposals, of which 245,614 pass
  support. Those replay events are not linked by identifiers to the 200,016
  quota-retained calibration rows. The 45,598 difference is unclassified and
  must not be called either quota surplus or observational loss.
- Both binary-component masses must satisfy the adopted MIST interpolation
  support. The forward model uses phase -1 and phase 0 rows, as specified in
  the manuscript's model description.
- Nuisance sampling and selection are part of this operator; see
  `sampling_provenance.md` and `../config/`.

## Archived result boundary

Keep the archived result arrays, truth vectors, and source figures byte-stable.
New analyses belong in a new run directory with a new response hash, explicit
seed, design, outputs, and scope statement. Historical summary files do not
contain every data vector, fitted state vector, interval endpoint, or
convergence flag; do not infer missing quantities from aggregate summaries.

The project's original frozen review ZIP remains intact outside this release
candidate. The curated files here were copied from it; the SHA-256 and source
Git blob identity are recorded in `release_manifest.json`.
