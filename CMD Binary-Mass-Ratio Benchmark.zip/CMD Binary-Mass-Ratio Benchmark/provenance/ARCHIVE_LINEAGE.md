# Archive lineage

This release candidate is a curated copy of the existing review ZIP. The
original ZIP is preserved at
`../submission/reproducibility_package.zip` in the working project and was not
rewritten while preparing this candidate.

- Original GitHub repository: `https://github.com/chihuanbin/binary_mass_ratio`
- Source commit: `95c2a7f5bb88d8d9b5cc5572ecc3346553d6fe1c`
- Source path: `reproducibility_package.zip`
- Git blob SHA-1: `513844cea11a761b154a68dee2abc45233d33617`
- Candidate derivation: curated archive files plus the path-independent
  `cmd_binary_benchmark` API, release documentation, and release manifest.

The ZIP lineage establishes the identity of the archived input. It does not
mean that the framework code and documentation in this release candidate
already exist at that public commit.
