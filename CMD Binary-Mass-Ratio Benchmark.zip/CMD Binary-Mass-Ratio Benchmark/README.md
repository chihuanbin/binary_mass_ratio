# CMD Binary-Mass-Ratio Benchmark

A reproducible benchmark resource for studying how a specified finite CMD
response affects **detection**, **population reconstruction**, and **interval
coverage**. The repository contains one frozen Gaia-like response and its
archived validation products, plus a small path-independent Python API for
applying the same categories of diagnostics to another response.

## What this repository supports

- Inspect and validate the archived 54-true-state by 55-outcome response.
- Project a proposed intrinsic population through a response matrix.
- Compare a specified alternative with a specified null using Pearson or
  simple-versus-simple likelihood-ratio statistics.
- Calibrate thresholds on independent null draws, assess null rejection on a
  second independent sample, and estimate alternative rejection probability.
- Score statewise fraction error and marginal interval coverage when external
  estimates and intervals are supplied.
- Compute aggregate summaries such as bin-centre mean mass ratio with
  `weighted_summary` and an explicit value per latent state.
- Regenerate the included deterministic contrast diagnostic.

The generic API is in [`src/cmd_binary_benchmark`](src/cmd_binary_benchmark).
Definitions, scope rules, and a minimal example are in
[`docs/FRAMEWORK.md`](docs/FRAMEWORK.md); setup and archived-data instructions
are in [`docs/USING_BENCHMARK.md`](docs/USING_BENCHMARK.md).

## Quick start

Use Python 3.10 or later. Install the lightweight benchmark API and validate
the response artifact:

```sh
python -m pip install -e .
cmd-benchmark validate-response \
  data/frozen/response_54x55.npy
```

This command checks matrix dimensions, finite non-negative entries, row sums,
and detection efficiencies. A Python example for defining new null and
alternative populations and running separated threshold/null/power samples is
provided in the use guide.

## Frozen benchmark and interpretation

The archived matrix is conditional on the declared within-bin sampling,
interpolation support, cluster nuisance sampling, independent-band noise
model, sensitivity cuts, and inverse-fit grid. It was calibrated with 3,704
retained rows in each of 54 latent states. Its last outcome is
`NOT_OBSERVED`; the detected response has unit efficiency for this restricted
operator. The archive does not provide the raw MIST isochrones or the full
Hunt--Reffert cluster/member inputs needed to rebuild the response from raw
data. A separate proposal replay's 245,614 in-support events are not linked
to the 200,016 quota-retained calibration rows; the 45,598 difference is
unclassified and is not assigned to quota surplus or observational loss.

The archived results remain fixed reference products. They are not silently
recomputed by importing this package. The added Python framework does not
claim to reproduce the archived inverse-fit/bootstrap runs or the full
historical 672-cell likelihood-ratio grid. In particular, the published
surface contains the documented 56 single-q-bin cells; three known
two-q-bin count mismatches remain outside it. The focused null check covers
one comparison only. The full evidence boundary is summarized in
[`provenance/claim_evidence_scope.csv`](provenance/claim_evidence_scope.csv)
and [`provenance/sampling_provenance.md`](provenance/sampling_provenance.md).

## Repository map

| Path | Contents |
|---|---|
| `src/cmd_binary_benchmark/` | Reusable array-level benchmark metrics and CLI |
| `data/frozen/` | Standalone numeric NPY export of the frozen response |
| `data/derived/legacy_results/` | Frozen response and archived result arrays |
| `data/derived/` | Frozen truth vectors, summaries, coverage and contrast outputs |
| `figures/` | Derived figures and their tabular/source records |
| `config/` | Prespecified archived experiment descriptions |
| `provenance/` | Operator definition, sampling and uncertainty provenance, checksums |
| `scripts/` | Deterministic projection diagnostic with caller-selected output path |

## Data, provenance, and safety

The `data/` files are derived benchmark artifacts. Raw cluster/member
catalogues and MIST isochrones are not included. Their omission is deliberate;
the package does not assert raw-input-to-response reproduction. The response
is also exported losslessly as a standalone numeric NPY file for safe loading;
the original NPZ and output hashes are recorded in `provenance/SHA256SUMS.txt`.

The legacy `.npz` files include Python object metadata. Load only the supplied,
hash-checked files. Do not enable pickle loading for an NPZ obtained from an
untrusted source. The new API itself accepts NumPy arrays and does not need to
load pickle metadata.

## Citation and license

Please cite our paper ��A Simulation Benchmark for Detection, Reconstruction, and Calibration of Binary Mass-Ratio Distributions from Color�CMagnitude Diagrams��, if you use this code.

## Scientific scope

This is a benchmark for one finite operator and declared simulation designs.
It does not establish a universal recoverability limit, Gaia catalogue
completeness, real-cluster binary structure, or performance guarantees for a
different response. See [`docs/FRAMEWORK.md`](docs/FRAMEWORK.md) before
adapting it to another target.