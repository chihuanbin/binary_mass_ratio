"""Command line checks for archived response matrices."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .core import validate_response


def main() -> None:
    parser = argparse.ArgumentParser(prog="cmd-benchmark")
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("validate-response", help="check a row-stochastic response matrix")
    check.add_argument("archive", type=Path, help="safe NPY matrix or trusted NPZ containing a response array")
    check.add_argument("--array", default="R", help="NPZ array key (default: R)")
    args = parser.parse_args()
    if args.command == "validate-response":
        if args.archive.suffix.lower() == ".npy":
            matrix = np.load(args.archive, allow_pickle=False)
            array_key = None
        elif args.archive.suffix.lower() == ".npz":
            # The historical release NPZs are hash-recorded project files,
            # but contain object-valued metadata. Never point this branch at
            # an untrusted NPZ.
            with np.load(args.archive, allow_pickle=True) as archive:
                if args.array not in archive.files:
                    raise SystemExit(f"array {args.array!r} not found; available: {archive.files}")
                matrix = archive[args.array]
                array_key = args.array
        else:
            raise SystemExit("response file must end in .npy or .npz")
        result = validate_response(matrix)
        result["archive"] = str(args.archive)
        result["array"] = array_key or "<whole NPY array>"
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
