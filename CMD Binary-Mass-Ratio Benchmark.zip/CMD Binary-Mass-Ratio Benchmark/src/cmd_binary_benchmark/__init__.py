"""Reusable metrics for finite-state color--magnitude diagram benchmarks."""

from .core import (
    benchmark_detection,
    empirical_threshold,
    log_likelihood_ratio,
    marginal_coverage,
    maximum_absolute_error,
    pearson_discrepancy,
    project_population,
    sample_multinomial,
    validate_response,
    wilson_interval,
    weighted_summary,
)

__all__ = [
    "benchmark_detection",
    "empirical_threshold",
    "log_likelihood_ratio",
    "marginal_coverage",
    "maximum_absolute_error",
    "pearson_discrepancy",
    "project_population",
    "sample_multinomial",
    "validate_response",
    "wilson_interval",
    "weighted_summary",
]
