"""Array-level benchmark operations with no project-specific file paths.

Response convention: rows are true states. Columns are detected states,
followed by one final non-detection state. Population projection conditions
on detection by default, matching analyses of detected catalogues.
"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

import numpy as np


def _probability_vector(values: Any, name: str) -> np.ndarray:
    x = np.asarray(values, dtype=np.float64)
    if x.ndim != 1 or x.size == 0:
        raise ValueError(f"{name} must be a non-empty one-dimensional vector")
    if not np.all(np.isfinite(x)) or np.any(x < 0):
        raise ValueError(f"{name} must contain finite, non-negative values")
    total = float(x.sum())
    if not np.isclose(total, 1.0, rtol=0.0, atol=1e-10):
        raise ValueError(f"{name} must sum to one; received {total:.16g}")
    return x


def validate_response(response: Any, *, atol: float = 1e-12) -> dict[str, Any]:
    """Validate a row-stochastic response and return dimensions/efficiencies."""
    if not np.isfinite(atol) or atol <= 0:
        raise ValueError("atol must be finite and positive")
    r = np.asarray(response, dtype=np.float64)
    if r.ndim != 2 or min(r.shape) < 1:
        raise ValueError("response must be a non-empty two-dimensional matrix")
    if not np.all(np.isfinite(r)) or np.any(r < 0):
        raise ValueError("response probabilities must be finite and non-negative")
    sums = r.sum(axis=1)
    if not np.allclose(sums, 1.0, rtol=0.0, atol=atol):
        raise ValueError("each response row must sum to one, including non-detection")
    return {
        "n_true_states": int(r.shape[0]),
        "n_outcomes": int(r.shape[1]),
        "row_sum_max_abs_error": float(np.max(np.abs(sums - 1.0))),
        "efficiency_min": float(r[:, :-1].sum(axis=1).min()) if r.shape[1] > 1 else 0.0,
        "efficiency_max": float(r[:, :-1].sum(axis=1).max()) if r.shape[1] > 1 else 0.0,
    }


def project_population(population: Any, response: Any, *, condition_on_detection: bool = True) -> np.ndarray:
    """Project true-state fractions through a true-state-by-outcome response.

    When conditioning on detection, the final response column is treated as
    non-detection and omitted before renormalizing. The returned vector is the
    distribution among detected outcomes. Set ``condition_on_detection=False``
    to return probabilities across all response outcomes.
    """
    t = _probability_vector(population, "population")
    r = np.asarray(response, dtype=np.float64)
    validate_response(r)
    if t.size != r.shape[0]:
        raise ValueError("population length must match the response true-state axis")
    projected = t @ r
    if not condition_on_detection:
        return projected
    detected = projected[:-1]
    efficiency = float(detected.sum())
    if not np.isfinite(efficiency) or efficiency <= 0:
        raise ValueError("population has zero or invalid detection efficiency")
    return detected / efficiency


def sample_multinomial(probabilities: Any, sample_size: int, replicates: int,
                       rng: np.random.Generator) -> np.ndarray:
    """Draw independent multinomial count vectors from an explicit Generator."""
    p = _probability_vector(probabilities, "probabilities")
    if not isinstance(sample_size, (int, np.integer)) or sample_size < 1:
        raise ValueError("sample_size must be a positive integer")
    if not isinstance(replicates, (int, np.integer)) or replicates < 1:
        raise ValueError("replicates must be a positive integer")
    if not isinstance(rng, np.random.Generator):
        raise TypeError("rng must be an explicit numpy.random.Generator")
    return rng.multinomial(int(sample_size), p, size=int(replicates))


def pearson_discrepancy(counts: Any, null_probabilities: Any,
                        *, probability_floor: float = 1e-12) -> float:
    """Pearson discrepancy on empirical proportions, without an N multiplier.

    A positive count in a zero-probability null category returns infinity.
    ``probability_floor`` matches the archived statistic's denominator floor.
    """
    n = np.asarray(counts, dtype=np.float64)
    p = np.asarray(null_probabilities, dtype=np.float64)
    if n.ndim != 1 or p.shape != n.shape or n.size == 0:
        raise ValueError("counts and null probabilities must be same-length vectors")
    if not np.all(np.isfinite(n)) or np.any(n < 0) or not np.all(n == np.floor(n)):
        raise ValueError("counts must be finite non-negative integers")
    p = _probability_vector(p, "null_probabilities")
    if not np.isfinite(probability_floor) or probability_floor <= 0:
        raise ValueError("probability_floor must be finite and positive")
    total = n.sum()
    if total <= 0:
        raise ValueError("counts must have a positive total")
    observed = n / total
    if np.any((p == 0) & (observed > 0)):
        return float("inf")
    return float(np.sum((observed - p) ** 2 / np.maximum(p, probability_floor)))


def log_likelihood_ratio(counts: Any, null_probabilities: Any,
                         alternative_probabilities: Any) -> float:
    """Return ``sum_j n_j log(p_alt[j] / p_null[j])`` exactly on support."""
    n = np.asarray(counts, dtype=np.float64)
    p0 = np.asarray(null_probabilities, dtype=np.float64)
    p1 = np.asarray(alternative_probabilities, dtype=np.float64)
    if n.ndim != 1 or p0.shape != n.shape or p1.shape != n.shape or n.size == 0:
        raise ValueError("counts and both probability vectors must have equal length")
    if not np.all(np.isfinite(n)) or np.any(n < 0) or not np.all(n == np.floor(n)):
        raise ValueError("counts must be finite non-negative integers")
    p0 = _probability_vector(p0, "null_probabilities")
    p1 = _probability_vector(p1, "alternative_probabilities")
    used = n > 0
    if np.any(used & (p0 == 0) & (p1 > 0)):
        return float("inf")
    if np.any(used & (p1 == 0) & (p0 > 0)):
        return float("-inf")
    if np.any(used & (p0 == 0) & (p1 == 0)):
        raise ValueError("positive observed count in a category impossible under both hypotheses")
    return float(np.sum(n[used] * (np.log(p1[used]) - np.log(p0[used]))))


def empirical_threshold(null_statistics: Any, *, alpha: float = 0.05) -> float:
    """Return the linear empirical ``(1-alpha)`` quantile for strict-tail tests."""
    s = np.asarray(null_statistics, dtype=np.float64)
    if s.ndim != 1 or s.size == 0 or np.any(np.isnan(s)):
        raise ValueError("null_statistics must be a non-empty vector without NaNs")
    if not 0 < alpha < 1:
        raise ValueError("alpha must be between zero and one")
    return float(np.quantile(s, 1.0 - alpha, method="linear"))


def wilson_interval(successes: int, trials: int, *, confidence: float = 0.95) -> tuple[float, float]:
    """Wilson score interval for a binomial rejection/coverage proportion."""
    if not isinstance(successes, (int, np.integer)) or not isinstance(trials, (int, np.integer)):
        raise TypeError("successes and trials must be integers")
    if trials < 1 or successes < 0 or successes > trials:
        raise ValueError("require 0 <= successes <= trials and trials > 0")
    if not 0 < confidence < 1:
        raise ValueError("confidence must be between zero and one")
    from statistics import NormalDist
    z = NormalDist().inv_cdf((1.0 + confidence) / 2.0)
    phat = successes / trials
    z2 = z * z
    denom = 1.0 + z2 / trials
    center = (phat + z2 / (2.0 * trials)) / denom
    half = z * np.sqrt(phat * (1.0 - phat) / trials + z2 / (4.0 * trials * trials)) / denom
    return float(center - half), float(center + half)


def benchmark_detection(statistic: Callable[[np.ndarray], float],
                        null_probabilities: Any, alternative_probabilities: Any,
                        *, sample_size: int, n_threshold: int,
                        n_null_check: int, n_alternative: int,
                        alpha: float, rng: np.random.Generator) -> dict[str, Any]:
    """Calibrate a strict-tail test and assess it on independent draws.

    Threshold calibration, held-out null-size assessment, and alternative power
    use independent multinomial samples. The caller chooses the statistic and
    supplies a Generator so the random stream is explicit and recordable.
    """
    p0 = _probability_vector(null_probabilities, "null_probabilities")
    p1 = _probability_vector(alternative_probabilities, "alternative_probabilities")
    if p0.shape != p1.shape:
        raise ValueError("null and alternative vectors must have equal length")
    if not isinstance(rng, np.random.Generator):
        raise TypeError("rng must be an explicit numpy.random.Generator")
    null_train = sample_multinomial(p0, sample_size, n_threshold, rng)
    train_stats = np.asarray([statistic(row) for row in null_train], dtype=np.float64)
    threshold = empirical_threshold(train_stats, alpha=alpha)
    null_eval = sample_multinomial(p0, sample_size, n_null_check, rng)
    alt_eval = sample_multinomial(p1, sample_size, n_alternative, rng)
    null_stats = np.asarray([statistic(row) for row in null_eval], dtype=np.float64)
    alt_stats = np.asarray([statistic(row) for row in alt_eval], dtype=np.float64)
    null_reject = int(np.count_nonzero(null_stats > threshold))
    alt_reject = int(np.count_nonzero(alt_stats > threshold))
    return {
        "sample_size": int(sample_size), "alpha": float(alpha),
        "threshold": threshold, "threshold_method": "linear empirical quantile; reject strictly greater",
        "n_threshold": int(n_threshold), "n_null_check": int(n_null_check),
        "n_alternative": int(n_alternative),
        "null_rejections": null_reject,
        "null_rate": null_reject / n_null_check,
        "null_wilson_interval": wilson_interval(null_reject, n_null_check),
        "alternative_rejections": alt_reject,
        "power": alt_reject / n_alternative,
        "power_wilson_interval": wilson_interval(alt_reject, n_alternative),
    }


def maximum_absolute_error(estimate: Any, truth: Any) -> float:
    """Maximum componentwise absolute error for matched fraction vectors."""
    a = np.asarray(estimate, dtype=np.float64)
    t = np.asarray(truth, dtype=np.float64)
    if a.shape != t.shape or a.ndim != 1 or a.size == 0:
        raise ValueError("estimate and truth must be same-shape non-empty vectors")
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(t)):
        raise ValueError("estimate and truth must be finite")
    return float(np.max(np.abs(a - t)))


def weighted_summary(population: Any, state_values: Any) -> float:
    """Return a population-weighted mean of values attached to true states."""
    t = _probability_vector(population, "population")
    x = np.asarray(state_values, dtype=np.float64)
    if x.ndim != 1 or x.shape != t.shape or not np.all(np.isfinite(x)):
        raise ValueError("state_values must be a finite vector matching population")
    return float(t @ x)


def marginal_coverage(lower: Any, upper: Any, truth: Any) -> np.ndarray:
    """Boolean statewise coverage for equal-length marginal interval vectors."""
    lo = np.asarray(lower, dtype=np.float64)
    hi = np.asarray(upper, dtype=np.float64)
    t = np.asarray(truth, dtype=np.float64)
    if lo.ndim != 1 or lo.shape != hi.shape or lo.shape != t.shape or lo.size == 0:
        raise ValueError("lower, upper and truth must be same-shape non-empty vectors")
    if not np.all(np.isfinite(lo)) or not np.all(np.isfinite(hi)) or not np.all(np.isfinite(t)):
        raise ValueError("interval bounds and truth must be finite")
    if np.any(lo > hi):
        raise ValueError("every lower bound must be <= its upper bound")
    return (lo <= t) & (t <= hi)
