"""Write checksums and a provenance manifest for this release tree."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "provenance/release_manifest.json"
SUMS = ROOT / "provenance/SHA256SUMS.txt"
SOURCE_ARCHIVE = ROOT.parent / "submission/reproducibility_package.zip"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def files_for_manifest() -> list[Path]:
    excluded = {MANIFEST.resolve(), SUMS.resolve()}
    return sorted(
        p for p in ROOT.rglob("*")
        if p.is_file() and p.resolve() not in excluded
        and "__pycache__" not in p.parts and p.suffix != ".pyc"
    )


def main() -> None:
    paths = files_for_manifest()
    lines = [f"{digest(p)}  {p.relative_to(ROOT).as_posix()}" for p in paths]
    SUMS.write_text("\n".join(lines) + "\n", encoding="utf-8")
    sums_entry = {"path": SUMS.relative_to(ROOT).as_posix(),
                  "size": SUMS.stat().st_size, "sha256": digest(SUMS)}
    entries = [{"path": p.relative_to(ROOT).as_posix(),
                "size": p.stat().st_size, "sha256": digest(p)} for p in paths]
    manifest = {
        "release_candidate": "CMD Binary-Mass-Ratio Benchmark",
        "candidate_version": "0.1.0",
        "generated_files_excluded_from_checksum_list": [
            "provenance/SHA256SUMS.txt", "provenance/release_manifest.json"],
        "source_archive": {
            "path_in_working_project": "submission/reproducibility_package.zip",
            "size": SOURCE_ARCHIVE.stat().st_size,
            "sha256": digest(SOURCE_ARCHIVE),
            "github_commit": "95c2a7f5bb88d8d9b5cc5572ecc3346553d6fe1c",
            "github_blob_sha1": "513844cea11a761b154a68dee2abc45233d33617",
        },
        "baseline_policy": "Archived response and result artifacts are immutable inputs; new runs use separate output directories.",
        "raw_input_to_response": "NOT_REPRODUCED; raw MIST and full cluster/member catalogue inputs are not included.",
        "public_license": "NOT_ASSIGNED; maintainer decision required before describing this as openly licensed.",
        "files": entries + [sums_entry],
    }
    MANIFEST.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"files_checksummed": len(paths),
                      "manifest": str(MANIFEST), "sha256sums": str(SUMS)}, indent=2))


if __name__ == "__main__":
    main()
