# Result record schema

Every new benchmark run should save one machine-readable JSON record with at
least these fields:

```json
{
  "schema_version": "1.0",
  "run_id": "unique-stable-id",
  "operator": {
    "response_file": "relative/path/to/response.npz",
    "response_sha256": "...",
    "orientation": "true_state_by_outcome",
    "state_order_file": "relative/path/to/state_labels.csv",
    "non_detection_column": "last"
  },
  "design": {
    "truth_id": "...",
    "null_id": "...",
    "alternative_id": "...",
    "baseline_id": "...",
    "sample_size": 20000,
    "alpha": 0.05,
    "n_threshold": 2000,
    "n_null_check": 10000,
    "n_alternative": 2000,
    "seed": 0
  },
  "software": {"python": "...", "numpy": "..."},
  "detection": {},
  "reconstruction": {},
  "coverage": {},
  "limitations": []
}
```

This is a minimum reporting contract, not a claim that those values are
available for the frozen historical runs. Include only results actually
computed. For reconstruction, record the estimator and its convergence/failure
status. For coverage, record the interval procedure, independent replicate
unit, and statewise or replicate-level summaries. Keep a separate provenance
record for nuisance sampling, selection, bin definitions, and any response
uncertainty procedure.
