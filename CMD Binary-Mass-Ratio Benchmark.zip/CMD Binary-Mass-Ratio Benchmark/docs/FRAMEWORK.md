# Benchmark framework

## Aim

The framework keeps three estimands separate. For a true-state population
`t` and response `R`, it addresses:

1. **Detection:** rejection probability for an explicitly specified null and
   alternative.
2. **Reconstruction:** aggregate and statewise error of supplied estimates
   relative to a truth and a declared baseline.
3. **Coverage:** statewise coverage of supplied marginal intervals under a
   declared replication design.

It does not rank estimators unless the estimand, baseline, replicated data,
and uncertainty for the comparison have all been defined. A result in one
track is not evidence for a result in another.

## Response and projection contract

`R[i, j]` is the probability of detected outcome `j` given true state `i`.
The final response column is the non-detection outcome. Rows are finite,
non-negative probabilities summing to one. Latent fractions `t[i]` sum to one.
For a detected-catalogue analysis:

\[
\epsilon_i = \sum_{j\in\mathrm{det}} R_{ij},\qquad
p_j(t) = \frac{\sum_i t_i R_{ij}}{\sum_i t_i\epsilon_i}.
\]

This is selection-conditioned projection. When the target is the unconditional
outcome distribution, retain the non-detection column instead of conditioning.
States with zero detection efficiency are not identified from detected data
without additional assumptions.

Use `validate_response` before analysis and `project_population` to calculate
`p(t)`. The generic API accepts arrays; it does not infer the meaning or
ordering of states from labels. Preserve state order in the input manifest.

## Detection protocol

Define `p0` and `p1` before inspecting simulated alternatives. Draw three
independent sets of multinomial vectors:

- threshold calibration under `p0`;
- held-out null assessment under `p0`;
- power assessment under `p1`.

`benchmark_detection` uses a caller-supplied statistic, an empirical linear
`(1-alpha)` quantile, and the strict rule `statistic > threshold`. It reports
both held-out null rejection and alternative rejection, with Wilson intervals.
Record the statistic, alpha, random seed/generator, all replicate counts,
population definitions, and the response hash with the returned summary.
Threshold estimation and response estimation uncertainty are not propagated
by this helper.

Built-in statistics are:

- `pearson_discrepancy(n, p0) = sum_j (n_j/N - p0_j)^2 / max(p0_j, 1e-12)`;
  it omits the conventional multiplier `N` to match the archived discrepancy.
- `log_likelihood_ratio(n, p0, p1) = sum_j n_j log(p1_j/p0_j)` with exact
  zero-support handling and no probability floor.

These definitions deliberately differ in their support/floor treatment.
Do not substitute one for the other or compare power without retaining its
null calibration and alternative definition.

## Reconstruction protocol

Supply estimates from an explicitly named estimator, the simulated truth, and
a data-independent baseline. `maximum_absolute_error` returns
`max_i |estimate_i - truth_i|`; call it separately for the estimator and the
baseline on the same truth. `weighted_summary` computes an aggregate weighted
mean for any finite value attached to each state. Report aggregate summaries
separately from local errors. If a mass-ratio summary is used, state whether it
uses bin centres or within-bin continuous draws and preserve the population
weights.

The framework does not provide a population inversion algorithm. An estimator
must be supplied by the study and validated on the same response and sampling
design. Do not interpret an EM iteration cap as convergence; save convergence
flags and per-fit diagnostics in new studies.

## Coverage protocol

`marginal_coverage(lower, upper, truth)` returns a Boolean indicator per state.
Aggregate those indicators at the independent simulation-replicate level.
When reporting uncertainty for average coverage, resample the independent
replicates, not the state indicators within a replicate. Marginal coverage and
all-state containment are different summaries; the latter is not a simultaneous
confidence region.

## Archived operator boundary

The frozen operator in `data/derived/legacy_results/calibration_200k.npz` is
54 true states by 55 outcomes (54 detected plus `NOT_OBSERVED`), trained on
3,704 retained examples in each state. Its empirical operator is conditional
on the project-specific support rule, nuisance sampling, photometric noise,
sensitivity cuts, and inverse grid. The archived retained response rows have
unit detected efficiency. These conditions are part of the benchmark, not
universal properties of Gaia or of CMD inference.

The project archives detection surfaces and reconstruction/coverage summaries.
It does not include the underlying outer estimates, interval endpoints,
draw-level simulation arrays for every historical run, or raw inputs needed to
rebuild the operator. Use the archived values as fixed products. Do not claim
that an API invocation reproduces them.

## Extension record

For each new target, keep a separate run folder with:

- response matrix and SHA-256; state labels/order; detection efficiencies;
- truth, null, alternative and baseline vectors, with definitions;
- sampling, nuisance and selection assumptions;
- estimator identity, settings, convergence/failure flags;
- seeds, threshold-calibration and held-out replicate counts;
- statewise estimates/intervals where permitted, aggregate outputs, and
  a machine-readable result summary;
- scope statement linking every claim to its experiment and limitation.

Never replace the archived operator or historical result files with outputs
from an extension. Use a new, versioned run directory.
