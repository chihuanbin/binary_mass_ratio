# Use the benchmark

## Install

The general-purpose metrics require NumPy only. From the repository root:

```sh
python -m pip install -e .
```

Install plotting dependencies only when you need to regenerate figures:

```sh
python -m pip install -e '.[figures]'
```

The recorded environment for the archived derived-artifact work used Python
3.13.5, NumPy 2.1.3, SciPy 1.15.3, and Matplotlib 3.10.0. The framework API
declares Python 3.10+ and NumPy 1.24+; numerical Monte Carlo streams can vary
between NumPy releases, so record exact versions for new runs.

## Check the frozen response

```sh
cmd-benchmark validate-response \
  data/frozen/response_54x55.npy
```

The command prints the response dimensions, maximum row-normalization error,
and minimum/maximum efficiency. It does not write files or rerun a simulation.

The original calibration NPZ also contains object-valued metadata from the
historical archive. For that NPZ only, the CLI uses pickle loading to access
the numeric response member. Use the standalone NPY for ordinary analysis.
Only run the NPZ branch on the supplied archive after checking
`provenance/SHA256SUMS.txt`; do not point it at an untrusted NPZ. The reusable
array API itself has no file-loading behavior.

## Project populations and compare tests

The following is a template for a new analysis. Supply ordered latent
fractions, a row-stochastic response matrix, and a predeclared alternative.
`R` must have detected outcomes in all but its final `NOT_OBSERVED` column.

```python
import numpy as np
from cmd_binary_benchmark import (
    benchmark_detection,
    log_likelihood_ratio,
    project_population,
)

# R has shape (n_true_states, n_detected_states + 1).
# t0 and t1 are predeclared, non-negative vectors summing to one.
p0 = project_population(t0, R)
p1 = project_population(t1, R)
rng = np.random.default_rng(20260928)

result = benchmark_detection(
    lambda counts: log_likelihood_ratio(counts, p0, p1),
    p0,
    p1,
    sample_size=20_000,
    n_threshold=2_000,
    n_null_check=10_000,
    n_alternative=2_000,
    alpha=0.05,
    rng=rng,
)
print(result)
```

This template generates new Monte Carlo data and does not reproduce the
archived paper results. For a Pearson comparison, replace the statistic with
`lambda counts: pearson_discrepancy(counts, p0)`. Keep the threshold-training,
held-out-null and alternative samples independent. Record a seed, and do not
choose alternatives after examining their results.

## Score reconstruction and intervals

Given an externally fitted vector `t_hat`, a fixed truth `t_true`, and a
data-independent baseline `t_base`:

```python
from cmd_binary_benchmark import maximum_absolute_error, weighted_summary

error_fit = maximum_absolute_error(t_hat, t_true)
error_base = maximum_absolute_error(t_base, t_true)
```

For an aggregate mean q computed from q-bin centres, tile the nine centres
across primary-mass bins in the same state order and call
`weighted_summary(t_true, q_centres_by_state)`, where
`q_centres_by_state = np.tile(np.arange(0.15, 1.0, 0.1), 6)` for this archive's
54-state order. The archived study reports this bin-centre quantity separately
from its local error.

Given marginal lower and upper bounds, compute statewise indicators:

```python
from cmd_binary_benchmark import marginal_coverage

covered = marginal_coverage(lower, upper, t_true)
coverage_fraction = covered.mean()
```

For repeated-sampling uncertainty, aggregate first within each independent
replicate, then resample those replicates. Keep point coverage and all-state
containment separate.

## Reproduce archived derived figures

The archived figure scripts are historical scripts, not stable API commands.
They write to paths under the repository and may replace derived figure files.
The deterministic projection script requires an explicit output directory and
refuses to replace its three named products unless `--overwrite` is supplied:

```sh
python scripts/diagnose_r7_feature_projection.py \
  --output-dir /tmp/cmd-benchmark-projection
```

The output includes a per-state CSV, a source/identity JSON record and a PDF.
It evaluates only two previously defined contrasts; it is not a new experiment
or a general information-loss statistic.

## What is not reproduced

This repository does not ship raw MIST isochrones or full cluster/member
catalogues. The raw-input-to-response build was not rerun. It does not contain
all draw-level inputs, all per-state inverse estimates, interval endpoints, or
per-fit convergence records for the historical validation. It therefore
cannot rerun every original simulation or independently reconstruct every
archived statistic. The current likelihood-ratio figure has 56 cells; the
full historical 672-cell grid is not claimed to be bitwise reproduced.
